<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once '../database/config.php';
require_once '../fpdf/fpdf.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die('<h2 style="color:red;text-align:center;margin-top:40px;">Please log in to access this page</h2>');
}

if (!isset($_GET['booking_id']) || !isset($_GET['hotel_id'])) {
    die('<h2 style="color:red;text-align:center;margin-top:40px;">Missing booking_id or hotel_id</h2>');
}
$booking_id = (int)$_GET['booking_id'];
$hotel_id = (int)$_GET['hotel_id'];
$bookings_table = "bookings_hotel_{$hotel_id}";
$rooms_table = "rooms_hotel_{$hotel_id}";

// Fetch hotel name, address, phone, email
$stmt = $pdo->prepare("SELECT name, address, phone, email FROM hotels WHERE id = ?");
$stmt->execute([$hotel_id]);
$hotel = $stmt->fetch();
$hotel_name = $hotel ? $hotel['name'] : 'Hotel';
$hotel_address = $hotel['address'] ?? '';
$hotel_phone = $hotel['phone'] ?? '';
$hotel_email = $hotel['email'] ?? '';

try {
    // Fetch booking and room details
    $stmt = $pdo->prepare("SELECT b.*, r.room_number, r.category FROM `$bookings_table` b JOIN `$rooms_table` r ON b.room_id = r.id WHERE b.id = ?");
    $stmt->execute([$booking_id]);
    $booking = $stmt->fetch();
    if (!$booking) {
        die('<h2 style="color:red;text-align:center;margin-top:40px;">Booking not found</h2>');
    }
} catch (PDOException $e) {
    die('<h2 style="color:red;text-align:center;margin-top:40px;">Booking table not found for this hotel.<br>Contact admin.</h2>');
}

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 15);

// Header Section
$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(0, 5, date('d/m/Y'), 0, 1);
$pdf->Cell(0, 5, date('d M Y', strtotime($booking['created_at'])), 0, 1);

// Logo and Title Section
$pdf->SetFont('Arial', 'B', 20);
$pdf->SetTextColor(0, 123, 255); // Blue color like Booking.com
$pdf->Cell(95, 10, $hotel_name, 0, 0);
$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(95, 5, 'This is your receipt', 0, 1, 'R');
$pdf->Cell(95, 5, '', 0, 0);
$pdf->Cell(95, 5, 'Booking Number', 0, 1, 'R');
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(95, 5, '', 0, 0);
$pdf->Cell(95, 5, $booking['id'], 0, 1, 'R');

$pdf->Ln(5);

// YOUR DETAILS Section
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 8, 'YOUR DETAILS', 0, 1);
$pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 190, $pdf->GetY());
$pdf->Ln(3);

$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Name:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, $booking['guest_name'], 0, 1);

$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Email address:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, $booking['email'] ?? 'Not provided', 0, 1);

$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Phone:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, $booking['guest_contact'], 0, 1);

$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Date:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, date('d M Y', strtotime($booking['created_at'])), 0, 1);

$pdf->Ln(5);

// BOOKING DETAILS Section
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 8, 'BOOKING DETAILS', 0, 1);
$pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 190, $pdf->GetY());
$pdf->Ln(3);

$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Property name:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, $hotel_name, 0, 1);

$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Property address:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, $hotel_address ?: 'Address not provided', 0, 1);

$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Booking number:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, $booking['id'], 0, 1);

$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Room details:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, 'Room ' . $booking['room_number'] . ' (' . $booking['category'] . ')', 0, 1);

$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Check-in:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, date('l, d F Y', strtotime($booking['checkin_date'])), 0, 1);

$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Check-out:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, date('l, d F Y', strtotime($booking['checkout_date'])), 0, 1);

// Add meal add-ons information if available
$meals_info = [];
if (!empty($booking['breakfast_total']) && $booking['breakfast_total'] > 0) {
    $meals_info[] = 'Breakfast: BDT ' . number_format($booking['breakfast_total'], 2);
}
if (!empty($booking['lunch_total']) && $booking['lunch_total'] > 0) {
    $meals_info[] = 'Lunch: BDT ' . number_format($booking['lunch_total'], 2);
}
if (!empty($booking['dinner_total']) && $booking['dinner_total'] > 0) {
    $meals_info[] = 'Dinner: BDT ' . number_format($booking['dinner_total'], 2);
}

if (!empty($meals_info)) {
    $pdf->SetTextColor(100, 100, 100);
    $pdf->Cell(50, 6, 'Meal Add-ons:', 0, 0);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(0, 6, implode(', ', $meals_info), 0, 1);
    
    if (!empty($booking['meal_total']) && $booking['meal_total'] > 0) {
        $pdf->SetTextColor(100, 100, 100);
        $pdf->Cell(50, 6, 'Total Meals:', 0, 0);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 6, 'BDT ' . number_format($booking['meal_total'], 2), 0, 1);
    }
}



// After booking details, add payment details:
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 8, 'PAYMENT DETAILS', 0, 1);
$pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 190, $pdf->GetY());
$pdf->Ln(3);
$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Total Amount:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, 'BDT ' . number_format($booking['total_amount'], 2), 0, 1);
$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Discount Amount:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$discount_amount = $booking['discount'] ?? 0;
$pdf->Cell(0, 6, 'BDT ' . number_format($discount_amount, 2), 0, 1);
$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Amount:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, 'BDT ' . number_format($booking['paid'] ?? 0, 2), 0, 1);
$pdf->SetTextColor(100, 100, 100);
$pdf->Cell(50, 6, 'Due Amount:', 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 6, 'BDT ' . number_format($booking['due'] ?? 0, 2), 0, 1);

// Additional guest information if available
if (!empty($booking['address']) || !empty($booking['profession']) || !empty($booking['nid'])) {
    $pdf->Ln(3);
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(0, 8, 'ADDITIONAL DETAILS', 0, 1);
    $pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 190, $pdf->GetY());
    $pdf->Ln(3);
    
    $pdf->SetFont('Arial', '', 10);
    if (!empty($booking['address'])) {
        $pdf->SetTextColor(100, 100, 100);
        $pdf->Cell(50, 6, 'Address:', 0, 0);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 6, $booking['address'], 0, 1);
    }
    
    if (!empty($booking['profession'])) {
        $pdf->SetTextColor(100, 100, 100);
        $pdf->Cell(50, 6, 'Profession:', 0, 0);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 6, $booking['profession'], 0, 1);
    }
    
    if (!empty($booking['nid'])) {
        $pdf->SetTextColor(100, 100, 100);
        $pdf->Cell(50, 6, 'NID:', 0, 0);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 6, $booking['nid'], 0, 1);
    }
}

// Payment breakdown if needed
if (isset($booking['discount']) && $booking['discount'] > 0) {
    $pdf->Ln(3);
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(0, 8, 'PAYMENT BREAKDOWN', 0, 1);
    $pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 190, $pdf->GetY());
    $pdf->Ln(3);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->SetTextColor(100, 100, 100);
    $pdf->Cell(50, 6, 'Discount:', 0, 0);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(0, 6, 'BDT ' . number_format($booking['discount'], 2), 0, 1);
    
    $pdf->SetTextColor(100, 100, 100);
    $pdf->Cell(50, 6, 'Paid amount:', 0, 0);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(0, 6, 'BDT ' . number_format(isset($booking['paid']) ? $booking['paid'] : $booking['total_amount'], 2), 0, 1);
    
    if (isset($booking['due']) && $booking['due'] > 0) {
        $pdf->SetTextColor(100, 100, 100);
        $pdf->Cell(50, 6, 'Due amount:', 0, 0);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(0, 6, 'BDT ' . number_format($booking['due'], 2), 0, 1);
    }
}

// Footer
$pdf->Ln(10);
$pdf->SetFont('Arial', '', 9);
$pdf->SetTextColor(120, 120, 120);
$pdf->Cell(0, 5, 'Your receipt is automatically generated', 0, 1, 'C');
$pdf->Cell(0, 5, 'This is proof of your transaction - it can\'t be used to claim VAT.', 0, 1, 'C');

$pdf->Output('I', 'Booking_' . $booking['id'] . '.pdf');
exit; 