<?php
session_start();
require_once '../database/config.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'owner')) {
    header('Location: ../login.php');
    exit();
}

if (isset($_GET['id'])) {
    $hotel_id = (int)$_GET['id'];
    
    try {
        // Start transaction
        $conn->begin_transaction();
        
        // Check if hotel exists
        $stmt = $conn->prepare('SELECT name FROM hotels WHERE id = ?');
        $stmt->bind_param('i', $hotel_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception('Hotel not found');
        }
        
        $hotel = $result->fetch_assoc();
        $hotel_name = $hotel['name'];
        
        // Delete related records in order (due to foreign key constraints)
        // 1. Delete bookings for rooms in this hotel
        $stmt = $conn->prepare('DELETE b FROM bookings b INNER JOIN rooms r ON b.room_id = r.id WHERE r.hotel_id = ?');
        $stmt->bind_param('i', $hotel_id);
        $stmt->execute();
        
        // 2. Delete rooms
        $stmt = $conn->prepare('DELETE FROM rooms WHERE hotel_id = ?');
        $stmt->bind_param('i', $hotel_id);
        $stmt->execute();
        
        // 3. Delete hotel managers
        $stmt = $conn->prepare('DELETE FROM hotel_managers WHERE hotel_id = ?');
        $stmt->bind_param('i', $hotel_id);
        $stmt->execute();
        
        // 4. Delete revenue records
        $stmt = $conn->prepare('DELETE FROM revenue WHERE hotel_id = ?');
        $stmt->bind_param('i', $hotel_id);
        $stmt->execute();
        
        // 5. Update users who were assigned to this hotel
        $stmt = $conn->prepare('UPDATE users SET hotel_id = NULL WHERE hotel_id = ?');
        $stmt->bind_param('i', $hotel_id);
        $stmt->execute();
        
        // 6. Finally delete the hotel
        $stmt = $conn->prepare('DELETE FROM hotels WHERE id = ?');
        $stmt->bind_param('i', $hotel_id);
        $stmt->execute();
        
        $conn->commit();
        $_SESSION['success'] = "Hotel '$hotel_name' deleted successfully!";
        
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = 'Error deleting hotel: ' . $e->getMessage();
    }
} else {
    $_SESSION['error'] = 'Hotel ID required.';
}

header('Location: ../dashboard.php');
exit();
?> 