<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../database/config.php';
require_once '../fpdf/fpdf.php';

// Start session to check user authentication
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die('Access denied. Please log in.');
}

// Validate input parameters
$hotel_id = isset($_GET['hotel_id']) ? intval($_GET['hotel_id']) : 0;
$start_date = isset($_GET['start_date']) ? trim($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? trim($_GET['end_date']) : '';

if (!$hotel_id || !$start_date || !$end_date) {
    die('Missing required parameters: hotel_id, start_date, and end_date are required.');
}

// Validate date format
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    die('Invalid date format. Please use YYYY-MM-DD format.');
}

// Validate date range
if ($start_date > $end_date) {
    die('Start date cannot be after end date.');
}

// Check user permissions
if ($_SESSION['user_role'] === 'admin') {
    // Admin can access any hotel
    if (!$hotel_id) {
        die('Hotel ID is required for admin access.');
    }
} else if ($_SESSION['user_role'] === 'manager') {
    // Manager can only access their assigned hotel
    $hotel_id = $_SESSION['hotel_id'] ?? 0;
    if (!$hotel_id) {
        die('No hotel assigned. Contact admin.');
    }
} else {
    die('Access denied. Insufficient permissions.');
}

try {
    // Build the per-hotel table names
$bookings_table = "bookings_hotel_{$hotel_id}";
$rooms_table = "rooms_hotel_{$hotel_id}";

    // Check if tables exist
    $stmt = $pdo->query("SHOW TABLES LIKE '$bookings_table'");
    if (!$stmt->fetch()) {
        die("Bookings table for hotel $hotel_id does not exist.");
    }

    $stmt = $pdo->query("SHOW TABLES LIKE '$rooms_table'");
    if (!$stmt->fetch()) {
        die("Rooms table for hotel $hotel_id does not exist.");
    }

    // Fetch hotel information
    $stmt = $pdo->prepare('SELECT name, address FROM hotels WHERE id = ?');
$stmt->execute([$hotel_id]);
$hotel = $stmt->fetch();
    
    if (!$hotel) {
        die("Hotel with ID $hotel_id not found.");
    }
    
    $hotel_name = $hotel['name'];
    $hotel_address = $hotel['address'] ?? '';

    // Fetch bookings in date range with comprehensive data including NID from guests table (no duplicates)
    $sql = "SELECT DISTINCT
                b.id, b.room_id, b.guest_name, b.guest_contact, b.nid_number, b.profession, b.email, 
                b.num_guests, b.reference, b.note, b.checkin_date, b.checkout_date, b.booking_type,
                b.total_amount, b.discount, b.paid, b.due, b.status,
                b.breakfast_enabled, b.breakfast_price, b.breakfast_quantity, b.breakfast_total,
                b.lunch_enabled, b.lunch_price, b.lunch_quantity, b.lunch_total,
                b.dinner_enabled, b.dinner_price, b.dinner_quantity, b.dinner_total,
                r.room_number,
                r.price as room_price,
                (SELECT g.nid FROM guests g WHERE g.name = b.guest_name AND g.phone = b.guest_contact LIMIT 1) as guest_nid,
                (SELECT g.profession FROM guests g WHERE g.name = b.guest_name AND g.phone = b.guest_contact LIMIT 1) as guest_profession,
                (SELECT g.email FROM guests g WHERE g.name = b.guest_name AND g.phone = b.guest_contact LIMIT 1) as guest_email
            FROM `$bookings_table` b 
            JOIN `$rooms_table` r ON b.room_id = r.id 
            WHERE b.checkin_date >= ? AND b.checkin_date <= ? 
            ORDER BY b.checkin_date ASC, b.id ASC";
    
    $stmt = $pdo->prepare($sql);
$stmt->execute([$start_date, $end_date]);
$bookings = $stmt->fetchAll();

    if (empty($bookings)) {
        die("No bookings found for the specified date range ($start_date to $end_date).");
    }

    // Calculate summary statistics
    $total_bookings = count($bookings);
    $total_revenue = 0;
    $total_paid = 0;
    $total_due = 0;
    $active_bookings = 0;
    $cancelled_bookings = 0;

    foreach ($bookings as $booking) {
        $total_revenue += $booking['total_amount'] ?? 0;
        $total_paid += $booking['paid'] ?? 0;
        $total_due += $booking['due'] ?? 0;
        
        if (($booking['status'] ?? '') === 'active') {
            $active_bookings++;
        } elseif (($booking['status'] ?? '') === 'cancelled') {
            $cancelled_bookings++;
        }
    }

    // Generate PDF with larger page size
    $pdf = new FPDF('L', 'mm', 'A3'); // Landscape A3 for more width
    $pdf->AddPage();
    
    // Set document properties
    $pdf->SetTitle("Guest History - $hotel_name");
    $pdf->SetAuthor('Hotel Management System');
    $pdf->SetCreator('FPDF');
    
    // Set auto page break with more margin
    $pdf->SetAutoPageBreak(true, 15);
    
    // Header
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, $hotel_name, 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 8, 'Guest History Report', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 6, "Period: " . date('F j, Y', strtotime($start_date)) . " to " . date('F j, Y', strtotime($end_date)), 0, 1, 'C');
    $pdf->Cell(0, 6, "Generated on: " . date('F j, Y \a\t g:i A'), 0, 1, 'C');
    
    if ($hotel_address) {
        $pdf->Cell(0, 6, "Address: $hotel_address", 0, 1, 'C');
    }
    
    $pdf->Ln(5);

    // Summary Statistics
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 8, 'Summary Statistics:', 0, 1, 'L');
    $pdf->SetFont('Arial', '', 10);
    
    $pdf->Cell(60, 6, "Total Bookings: $total_bookings", 0, 0);
    $pdf->Cell(60, 6, "Active Bookings: $active_bookings", 0, 0);
    $pdf->Cell(60, 6, "Cancelled Bookings: $cancelled_bookings", 0, 1);
    
    $pdf->Cell(60, 6, "Total Revenue: BDT " . number_format($total_revenue, 2), 0, 0);
    $pdf->Cell(60, 6, "Total Paid: BDT " . number_format($total_paid, 2), 0, 0);
    $pdf->Cell(60, 6, "Total Due: BDT " . number_format($total_due, 2), 0, 1);
    
    $pdf->Ln(3);
    
    // Meal Add-ons Legend
    $pdf->SetFont('Arial', 'B', 8);
    $pdf->Cell(0, 6, 'Meal Add-ons Legend: B=Breakfast, L=Lunch, D=Dinner (Format: Type(QuantityxPrice))', 0, 1, 'L');
    
    $pdf->Ln(3);

    // Table header with optimized column widths for A3
    $pdf->SetFont('Arial', 'B', 7);
    $header = [
        'ID', 'Room', 'Guest Name', 'Phone', 'NID', 'Profession', 'Email', 
        'Guests', 'Reference', 'Note', 'Meal Add-ons', 'Check-in', 'Check-out', 
        'Type', 'Total', 'Discount', 'Paid', 'Due', 'Status'
    ];
    
    // A3 width is 420mm, distribute columns accordingly
    $col_widths = [10, 15, 30, 20, 20, 20, 30, 10, 20, 25, 40, 20, 20, 12, 18, 15, 18, 18, 15];
    
    // Draw header
    foreach ($header as $i => $col) {
        $pdf->Cell($col_widths[$i], 8, $col, 1, 0, 'C');
    }
    $pdf->Ln();
    
    // Helper function to truncate long text
    function truncateText($text, $maxLength = 15) {
        if (strlen($text) <= $maxLength) {
            return $text;
        }
        return substr($text, 0, $maxLength - 3) . '...';
    }
    
    // Table rows with smaller font for better fit
    $pdf->SetFont('Arial', '', 6);
    $row_count = 0;
    
    foreach ($bookings as $booking) {
        // Check if we need a new page (every 20 rows for A3)
        if ($row_count > 0 && $row_count % 20 == 0) {
            $pdf->AddPage();
            // Redraw header on new page
            $pdf->SetFont('Arial', 'B', 7);
            foreach ($header as $i => $col) {
                $pdf->Cell($col_widths[$i], 8, $col, 1, 0, 'C');
            }
            $pdf->Ln();
            $pdf->SetFont('Arial', '', 6);
        }
        
        // Format meal add-ons information (compact format)
        $meal_addons = [];
        if (!empty($booking['breakfast_quantity']) && $booking['breakfast_quantity'] > 0) {
            $meal_addons[] = "B({$booking['breakfast_quantity']}x" . number_format($booking['breakfast_price'] ?? 0, 0) . ")";
        }
        if (!empty($booking['lunch_quantity']) && $booking['lunch_quantity'] > 0) {
            $meal_addons[] = "L({$booking['lunch_quantity']}x" . number_format($booking['lunch_price'] ?? 0, 0) . ")";
        }
        if (!empty($booking['dinner_quantity']) && $booking['dinner_quantity'] > 0) {
            $meal_addons[] = "D({$booking['dinner_quantity']}x" . number_format($booking['dinner_price'] ?? 0, 0) . ")";
        }
        
        // Also check for enabled flags and totals as fallback
        if (empty($meal_addons) && ($booking['breakfast_enabled'] || $booking['lunch_enabled'] || $booking['dinner_enabled'])) {
            if ($booking['breakfast_enabled'] && $booking['breakfast_total'] > 0) {
                $meal_addons[] = "B(" . ($booking['breakfast_quantity'] ?? 1) . "x" . number_format($booking['breakfast_price'] ?? 0, 0) . ")";
            }
            if ($booking['lunch_enabled'] && $booking['lunch_total'] > 0) {
                $meal_addons[] = "L(" . ($booking['lunch_quantity'] ?? 1) . "x" . number_format($booking['lunch_price'] ?? 0, 0) . ")";
            }
            if ($booking['dinner_enabled'] && $booking['dinner_total'] > 0) {
                $meal_addons[] = "D(" . ($booking['dinner_quantity'] ?? 1) . "x" . number_format($booking['dinner_price'] ?? 0, 0) . ")";
            }
        }
        
        $meal_info = !empty($meal_addons) ? implode(' ', $meal_addons) : 'None';
        
        $row = [
            $booking['id'],
            $booking['room_number'],
            truncateText($booking['guest_name'], 20),
            $booking['guest_contact'],
            truncateText($booking['nid_number'] ?? $booking['guest_nid'] ?? '', 15),
            truncateText($booking['profession'] ?? $booking['guest_profession'] ?? '', 15),
            truncateText($booking['email'] ?? $booking['guest_email'] ?? '', 20),
            $booking['num_guests'] ?? 1,
            truncateText($booking['reference'] ?? '', 15),
            truncateText($booking['note'] ?? '', 20),
            truncateText($meal_info, 25),
            date('M j, Y', strtotime($booking['checkin_date'])),
            date('M j, Y', strtotime($booking['checkout_date'])),
            ucfirst($booking['booking_type'] ?? 'offline'),
            'BDT ' . number_format($booking['total_amount'] ?? 0, 2),
            'BDT ' . number_format($booking['discount'] ?? 0, 2),
            'BDT ' . number_format($booking['paid'] ?? 0, 2),
            'BDT ' . number_format($booking['due'] ?? 0, 2),
            ucfirst($booking['status'] ?? 'active')
        ];
        
        foreach ($row as $i => $cell) {
            $pdf->Cell($col_widths[$i], 6, $cell, 1, 0, 'C');
        }
        $pdf->Ln();
        $row_count++;
    }

    // Footer with additional information
    $pdf->Ln(5);
    $pdf->SetFont('Arial', 'I', 8);
    $pdf->Cell(0, 6, "Note: This report includes all bookings with check-in dates between $start_date and $end_date.", 0, 1, 'L');
    $pdf->Cell(0, 6, "Meal add-ons and additional services are included in the total amount.", 0, 1, 'L');

    // Output PDF
    $filename = "Guest_History_{$hotel_name}_{$start_date}_to_{$end_date}.pdf";
    $filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $filename); // Sanitize filename
    
    $pdf->Output('D', $filename);
exit; 

} catch (Exception $e) {
    die('Error generating PDF: ' . $e->getMessage());
}
?> 