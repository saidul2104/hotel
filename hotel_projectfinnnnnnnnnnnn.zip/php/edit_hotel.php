<?php
session_start();
require_once '../database/config.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'owner')) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hotel_id = (int)$_POST['hotel_id'];
    $name = trim($_POST['name']);
    $address = trim($_POST['address']);
    $description = trim($_POST['description']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    // Validate input
    if (empty($name)) {
        $_SESSION['error'] = 'Hotel name is required.';
        header('Location: ../dashboard.php');
        exit();
    }

    try {
        // Update hotel in database
        $stmt = $pdo->prepare('UPDATE hotels SET name = ?, address = ?, description = ?, email = ?, phone = ? WHERE id = ?');
        $stmt->execute([$name, $address, $description, $email, $phone, $hotel_id]);
        $_SESSION['success'] = 'Hotel updated successfully!';
    } catch (Exception $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
    }
} else {
    $_SESSION['error'] = 'Invalid request method.';
}

header('Location: ../dashboard.php');
exit();
?> 