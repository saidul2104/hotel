<?php
session_start();
require_once '../database/config.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'owner')) {
    http_response_code(403);
    exit('Unauthorized');
}

if (isset($_GET['id'])) {
    $hotel_id = (int)$_GET['id'];
    
    $stmt = $pdo->prepare('SELECT id, name, address, description, email, phone FROM hotels WHERE id = ?');
    $stmt->execute([$hotel_id]);
    $hotel = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($hotel) {
        header('Content-Type: application/json');
        echo json_encode($hotel);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Hotel not found']);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Hotel ID required']);
}
?> 