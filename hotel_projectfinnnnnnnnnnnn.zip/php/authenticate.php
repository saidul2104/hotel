<?php
session_start();
require_once '../database/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $_SESSION['login_error'] = 'Please enter both username and password.';
        header('Location: ../login.php');
        exit();
    }

    $stmt = $pdo->prepare('SELECT id, name, email, password, role, hotel_id FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['hotel_id'] = $user['hotel_id'];
        
        if ($user['role'] === 'admin') {
            header('Location: ../dashboard.php');
        } else if ($user['role'] === 'manager') {
            header('Location: ../hotel_dashboard.php');
        } else {
            $_SESSION['login_error'] = 'Unknown user role.';
            header('Location: ../login.php');
        }
        exit();
    } else {
        $_SESSION['login_error'] = 'Invalid username or password.';
        header('Location: ../login.php');
        exit();
    }
} else {
    header('Location: ../login.php');
    exit();
}
?> 