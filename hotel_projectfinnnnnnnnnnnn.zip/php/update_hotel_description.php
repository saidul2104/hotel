<?php
session_start();
require_once '../database/config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$hotel_id = isset($_POST['hotel_id']) ? intval($_POST['hotel_id']) : 0;
$description = trim($_POST['description'] ?? '');

if (!$hotel_id) {
    echo json_encode(['success' => false, 'message' => 'Missing hotel ID']);
    exit();
}

try {
    $stmt = $pdo->prepare('UPDATE hotels SET description = ? WHERE id = ?');
    $stmt->execute([$description, $hotel_id]);
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} 