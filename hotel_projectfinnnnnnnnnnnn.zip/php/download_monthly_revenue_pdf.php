<?php
// Increase memory limit for PDF generation
ini_set('memory_limit', '512M');
ini_set('max_execution_time', 300);

session_start();
require_once '../database/config.php';
require_once '../fpdf/fpdf.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

// Get parameters
$hotel_id = isset($_GET['hotel_id']) ? intval($_GET['hotel_id']) : 0;
$revenue_month = isset($_GET['revenue_month']) ? $_GET['revenue_month'] : date('Y-m');

if (!$hotel_id) {
    die('Hotel ID is required');
}

// Fetch hotel info
$stmt = $pdo->prepare("SELECT name, address, phone, email FROM hotels WHERE id = ?");
$stmt->execute([$hotel_id]);
$hotel = $stmt->fetch();

if (!$hotel) {
    die('Hotel not found');
}

// Set up table names
$rooms_table = "rooms_hotel_{$hotel_id}";
$bookings_table = "bookings_hotel_{$hotel_id}";

// Calculate month details
$month_year = DateTime::createFromFormat('Y-m', $revenue_month);
$month_name = $month_year->format('F Y');
$days_in_month = $month_year->format('t');

// Get total monthly revenue (single query)
$stmt = $pdo->prepare("SELECT SUM(b.total_amount) as total_revenue, COUNT(*) as total_bookings FROM `$bookings_table` b JOIN `$rooms_table` r ON b.room_id = r.id WHERE DATE_FORMAT(b.checkin_date, '%Y-%m') = ? AND b.status = 'active'");
$stmt->execute([$revenue_month]);
$monthly_summary = $stmt->fetch();

$total_monthly_revenue = (float)($monthly_summary['total_revenue'] ?? 0);
$total_bookings = (int)($monthly_summary['total_bookings'] ?? 0);

// Get weekly breakdown (simpler than daily)
$weekly_data = [];
for ($week = 1; $week <= 5; $week++) {
    $week_start = $revenue_month . '-' . sprintf('%02d', ($week - 1) * 7 + 1);
    $week_end = $revenue_month . '-' . sprintf('%02d', min($week * 7, $days_in_month));
    
    $stmt = $pdo->prepare("SELECT SUM(b.total_amount) as revenue FROM `$bookings_table` b JOIN `$rooms_table` r ON b.room_id = r.id WHERE DATE(b.checkin_date) BETWEEN ? AND ? AND b.status = 'active'");
    $stmt->execute([$week_start, $week_end]);
    $weekly_revenue = (float)($stmt->fetch()['revenue'] ?? 0);
    $weekly_data[] = $weekly_revenue;
}

// Create simple PDF
class SimpleRevenuePDF extends FPDF {
    function Header() {
        global $hotel, $month_name;
        
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, $hotel['name'], 0, 1, 'C');
        
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 10, 'Monthly Revenue Report', 0, 1, 'C');
        $this->Cell(0, 8, $month_name, 0, 1, 'C');
        
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 6, 'Address: ' . $hotel['address'], 0, 1, 'C');
        $this->Cell(0, 6, 'Phone: ' . $hotel['phone'], 0, 1, 'C');
        
        $this->Ln(10);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Generated on: ' . date('d/m/Y H:i:s'), 0, 0, 'C');
    }
}

// Initialize PDF
$pdf = new SimpleRevenuePDF();
$pdf->AddPage();

// Summary Section
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Revenue Summary', 0, 1, 'L');
$pdf->SetFont('Arial', '', 12);

$pdf->Cell(60, 8, 'Total Revenue:', 0, 0);
$pdf->Cell(0, 8, 'BDT ' . number_format($total_monthly_revenue, 2), 0, 1);

$pdf->Cell(60, 8, 'Total Bookings:', 0, 0);
$pdf->Cell(0, 8, $total_bookings, 0, 1);

$pdf->Cell(60, 8, 'Average per Booking:', 0, 0);
$pdf->Cell(0, 8, 'BDT ' . number_format($total_bookings > 0 ? $total_monthly_revenue / $total_bookings : 0, 2), 0, 1);

$pdf->Cell(60, 8, 'Days in Month:', 0, 0);
$pdf->Cell(0, 8, $days_in_month . ' days', 0, 1);

$pdf->Cell(60, 8, 'Average Daily:', 0, 0);
$pdf->Cell(0, 8, 'BDT ' . number_format($total_monthly_revenue / $days_in_month, 2), 0, 1);

$pdf->Ln(10);

// Weekly Breakdown
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Weekly Revenue Breakdown', 0, 1, 'L');

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 8, 'Week', 1, 0, 'C');
$pdf->Cell(50, 8, 'Revenue (BDT)', 1, 0, 'C');
$pdf->Cell(50, 8, 'Percentage', 1, 1, 'C');

$pdf->SetFont('Arial', '', 10);
for ($i = 0; $i < count($weekly_data); $i++) {
    $week_num = $i + 1;
    $revenue = $weekly_data[$i];
    $percentage = $total_monthly_revenue > 0 ? ($revenue / $total_monthly_revenue) * 100 : 0;
    
    $pdf->Cell(30, 8, 'Week ' . $week_num, 1, 0, 'C');
    $pdf->Cell(50, 8, number_format($revenue, 2), 1, 0, 'R');
    $pdf->Cell(50, 8, number_format($percentage, 1) . ' BDT', 1, 1, 'R');
}

$pdf->Ln(10);

// Top 10 Bookings (if any)
if ($total_bookings > 0) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Top 10 Bookings by Amount', 0, 1, 'L');
    
    $stmt = $pdo->prepare("
        SELECT b.guest_name, b.total_amount, r.room_number, b.checkin_date
        FROM `$bookings_table` b 
        JOIN `$rooms_table` r ON b.room_id = r.id 
        WHERE DATE_FORMAT(b.checkin_date, '%Y-%m') = ? AND b.status = 'active'
        ORDER BY b.total_amount DESC
        LIMIT 10
    ");
    $stmt->execute([$revenue_month]);
    $top_bookings = $stmt->fetchAll();
    
    if (!empty($top_bookings)) {
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->Cell(50, 8, 'Guest Name', 1, 0, 'C');
        $pdf->Cell(30, 8, 'Room', 1, 0, 'C');
        $pdf->Cell(30, 8, 'Check-in', 1, 0, 'C');
        $pdf->Cell(40, 8, 'Amount (BDT)', 1, 1, 'C');
        
        $pdf->SetFont('Arial', '', 8);
        foreach ($top_bookings as $booking) {
            $pdf->Cell(50, 6, substr($booking['guest_name'], 0, 20), 1, 0, 'L');
            $pdf->Cell(30, 6, $booking['room_number'], 1, 0, 'C');
            $pdf->Cell(30, 6, date('d/m/Y', strtotime($booking['checkin_date'])), 1, 0, 'C');
            $pdf->Cell(40, 6, number_format($booking['total_amount'], 2), 1, 1, 'R');
        }
    }
}

// Output PDF
$pdf->Output('monthly_revenue_' . $revenue_month . '.pdf', 'D');
?> 