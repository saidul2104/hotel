<?php
session_start();
require_once '../database/config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$hotel_id = isset($_POST['hotel_id']) ? intval($_POST['hotel_id']) : 0;
$email = trim($_POST['email'] ?? '');
$new_password = trim($_POST['new_password'] ?? '');

if (!$hotel_id || !$email || !$new_password) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit();
}

$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

try {
    $stmt = $pdo->prepare('UPDATE users SET password=? WHERE email=? AND hotel_id=? AND role="manager"');
    $stmt->execute([$hashed_password, $email, $hotel_id]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Manager not found or update failed']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} 