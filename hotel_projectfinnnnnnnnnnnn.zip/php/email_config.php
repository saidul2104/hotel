<?php
// Email Configuration for Different Environments
// Update these settings based on your hosting provider

// For Local Development (XAMPP)
$local_email_config = [
    'method' => 'smtp',
    'host' => 'smtp.gmail.com',
    'username' => 'hotelgrowthsolutions@gmail.com',
    'password' => 'vumiombhsvqmojzs',
    'port' => 587,
    'secure' => 'tls',
    'auth' => true
];

// For Hosting Environment - Method 1: Built-in mail function
$hosting_email_config_1 = [
    'method' => 'mail',
    'from_email' => 'hotelgrowthsolutions@gmail.com',
    'from_name' => 'Hotel Management System'
];

// For Hosting Environment - Method 2: Hosting SMTP
$hosting_email_config_2 = [
    'method' => 'smtp',
    'host' => 'localhost',
    'port' => 25,
    'auth' => false,
    'from_email' => 'hotelgrowthsolutions@gmail.com',
    'from_name' => 'Hotel Management System'
];

// For Hosting Environment - Method 3: Gmail SMTP (if you have credentials)
$hosting_email_config_3 = [
    'method' => 'smtp',
    'host' => 'smtp.gmail.com',
    'username' => 'hotelgrowthsolutions@gmail.com',
    'password' => 'vumiombhsvqmojzs',
    'port' => 587,
    'secure' => 'tls',
    'auth' => true,
    'from_email' => 'hotelgrowthsolutions@gmail.com',
    'from_name' => 'Hotel Management System'
];

// Function to get email configuration based on environment
function get_email_config($environment = 'hosting') {
    global $local_email_config, $hosting_email_config_1, $hosting_email_config_2, $hosting_email_config_3;
    
    switch ($environment) {
        case 'local':
            return $local_email_config;
        case 'hosting':
        default:
            // Prioritize Gmail SMTP since we want to send from hotelgrowthsolutions@gmail.com
            return $hosting_email_config_3;
    }
}

// Function to configure PHPMailer based on environment
function configure_phpmailer($mail, $environment = 'hosting') {
    $config = get_email_config($environment);
    
    if ($config['method'] === 'mail') {
        $mail->isMail();
    } else {
        $mail->isSMTP();
        $mail->Host = $config['host'];
        $mail->Port = $config['port'];
        
        if (isset($config['auth']) && $config['auth']) {
            $mail->SMTPAuth = true;
            $mail->Username = $config['username'];
            $mail->Password = $config['password'];
        } else {
            $mail->SMTPAuth = false;
        }
        
        if (isset($config['secure'])) {
            $mail->SMTPSecure = $config['secure'];
        }
    }
    
    return $config;
}
?> 