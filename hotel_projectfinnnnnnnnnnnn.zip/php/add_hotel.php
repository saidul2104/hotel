<?php
session_start();
require_once '../database/config.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'owner')) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // Validate input
    if (empty($name)) {
        $_SESSION['error'] = 'Hotel name is required.';
        header('Location: ../dashboard.php');
        exit();
    }

    try {
        // Insert hotel into database (PDO) - include owner_id
        $owner_id = $_SESSION['user_id'];
        $stmt = $pdo->prepare('INSERT INTO hotels (name, address, phone, email, owner_id) VALUES (?, ?, ?, ?, ?)');
        if ($stmt->execute([$name, $address, $phone, $email, $owner_id])) {
            $hotel_id = $pdo->lastInsertId();

            // Create rooms table for this hotel
            $rooms_table = "rooms_hotel_{$hotel_id}";
            $pdo->exec("CREATE TABLE IF NOT EXISTS `$rooms_table` (
                id INT AUTO_INCREMENT PRIMARY KEY,
                room_number VARCHAR(50) NOT NULL,
                category VARCHAR(100),
                description TEXT,
                price DECIMAL(10,2),
                status VARCHAR(50) DEFAULT 'available',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(room_number)
            ) ENGINE=InnoDB");

            // Create bookings table for this hotel
            $bookings_table = "bookings_hotel_{$hotel_id}";
            $pdo->exec("CREATE TABLE IF NOT EXISTS `$bookings_table` (
                id INT AUTO_INCREMENT PRIMARY KEY,
                room_id INT NOT NULL,
                guest_name VARCHAR(255),
                guest_contact VARCHAR(255),
                checkin_date DATE,
                checkout_date DATE,
                checkin_time TIME,
                checkout_time TIME,
                total_amount DECIMAL(10,2),
                discount DECIMAL(10,2) DEFAULT 0.00,
                paid DECIMAL(10,2) DEFAULT 0.00,
                due DECIMAL(10,2) DEFAULT 0.00,
                status VARCHAR(50) DEFAULT 'active',
                booking_type VARCHAR(50),
                reference VARCHAR(100),
                note TEXT,
                breakfast_price DECIMAL(10,2) DEFAULT 0.00,
                breakfast_quantity INT DEFAULT 0,
                breakfast_total DECIMAL(10,2) DEFAULT 0.00,
                lunch_price DECIMAL(10,2) DEFAULT 0.00,
                lunch_quantity INT DEFAULT 0,
                lunch_total DECIMAL(10,2) DEFAULT 0.00,
                dinner_price DECIMAL(10,2) DEFAULT 0.00,
                dinner_quantity INT DEFAULT 0,
                dinner_total DECIMAL(10,2) DEFAULT 0.00,
                meal_total DECIMAL(10,2) DEFAULT 0.00,
                breakfast_enabled BOOLEAN DEFAULT FALSE,
                lunch_enabled BOOLEAN DEFAULT FALSE,
                dinner_enabled BOOLEAN DEFAULT FALSE,
                nid_number VARCHAR(50),
                profession VARCHAR(50),
                email VARCHAR(100),
                address TEXT,
                num_guests INT DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (room_id) REFERENCES `$rooms_table`(id) ON DELETE CASCADE
            ) ENGINE=InnoDB");

            $_SESSION['success'] = 'Hotel and tables added successfully!';
        } else {
            $_SESSION['error'] = 'Error adding hotel.';
        }
    } catch (Exception $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
    }
} else {
    $_SESSION['error'] = 'Invalid request method.';
}

header('Location: ../dashboard.php');
exit();
?> 