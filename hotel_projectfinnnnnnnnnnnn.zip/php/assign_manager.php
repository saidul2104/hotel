<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once '../database/config.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'owner')) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hotel_id = (int)$_POST['hotel_id'];
    $manager_name = trim($_POST['manager_name']);
    $manager_email = trim($_POST['manager_email']);
    $manager_password = trim($_POST['manager_password']);

    // Validate input
    if (empty($manager_name) || empty($manager_email) || empty($manager_password)) {
        $_SESSION['error'] = 'All manager fields are required.';
        header('Location: ../dashboard.php');
        exit();
    }

    // Check if email already exists
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$manager_email]);
    if ($stmt->fetch()) {
        $_SESSION['error'] = 'A user with this email already exists.';
        header('Location: ../dashboard.php');
        exit();
    }

    $hashed_password = password_hash($manager_password, PASSWORD_DEFAULT);
    $transactionStarted = false;
    try {
        $pdo->beginTransaction();
        $transactionStarted = true;
        // Remove any existing manager for this hotel
        $stmt = $pdo->prepare('DELETE FROM users WHERE role = ? AND hotel_id = ?');
        $stmt->execute(['manager', $hotel_id]);
        // Create manager user
        $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role, hotel_id) VALUES (?, ?, ?, ?, ?)');
        $role = 'manager';
        $stmt->execute([$manager_name, $manager_email, $hashed_password, $role, $hotel_id]);
        $pdo->commit();
        $_SESSION['success'] = "Manager assigned successfully! Email: $manager_email, Password: $manager_password";
    } catch (Exception $e) {
        if ($transactionStarted && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['error'] = 'Error assigning manager: ' . $e->getMessage();
    }
} else {
    $_SESSION['error'] = 'Invalid request method.';
}
header('Location: ../dashboard.php');
exit();
?> 