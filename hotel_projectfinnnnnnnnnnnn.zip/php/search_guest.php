<?php
session_start();
require_once '../database/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// Check if it's a POST request with phone number
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['phone'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Phone number is required']);
    exit();
}

$phone = trim($_POST['phone']);

if (empty($phone)) {
    http_response_code(400);
    echo json_encode(['error' => 'Phone number cannot be empty']);
    exit();
}

try {
    // Search for guest by phone number
    $stmt = $pdo->prepare("
        SELECT name, phone, nid, profession, email, address, no_of_guests
        FROM guests 
        WHERE phone = ?
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute([$phone]);
    $guest = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($guest) {
        // Guest found
        // Debug: Log the guest data
        error_log('Guest found: ' . json_encode($guest));
        echo json_encode([
            'success' => true,
            'guest' => $guest
        ]);
    } else {
        // No guest found
        echo json_encode([
            'success' => false,
            'message' => 'No guest found with this phone number'
        ]);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?> 