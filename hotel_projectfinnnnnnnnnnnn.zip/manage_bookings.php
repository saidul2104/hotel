<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'database/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get hotel_id from URL (admin) or from manager's user record
if ($_SESSION['user_role'] === 'admin') {
    $hotel_id = isset($_GET['hotel_id']) ? intval($_GET['hotel_id']) : 0;
    if (!$hotel_id) {
        header('Location: dashboard.php');
        exit();
    }
} else if ($_SESSION['user_role'] === 'manager') {
    $hotel_id = $_SESSION['hotel_id'] ?? 0;
    if (!$hotel_id) {
        echo '<h2 class="text-red-600">No hotel assigned. Contact admin.</h2>';
        exit();
    }
} else {
    header('Location: login.php');
    exit();
}

// Build the per-hotel table names
$bookings_table = "bookings_hotel_{$hotel_id}";
$rooms_table = "rooms_hotel_{$hotel_id}";

// Default sorting (no longer used in UI but kept for backward compatibility)
$sort_field = 'checkin_date';
$sort_dir = 'asc';

// Handle edit, delete actions
$message = '';

// Check for success message from URL
if (isset($_GET['message'])) {
    if ($_GET['message'] === 'updated') {
        $message = 'Booking updated successfully! All details including meal add-ons have been saved.';
    } elseif ($_GET['message'] === 'deleted') {
        $message = 'Booking deleted successfully!';
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['edit_booking'])) {
        $booking_id = $_POST['booking_id'];
        $guest_name = $_POST['guest_name'];
        $phone = $_POST['phone'];
        $status = $_POST['status'];
        $paid = isset($_POST['paid']) ? floatval($_POST['paid']) : 0;
        $discount = isset($_POST['discount']) ? floatval($_POST['discount']) : 0;
        $profession = $_POST['profession'] ?? '';
        $email = $_POST['email'] ?? '';
        $num_guests = $_POST['num_guests'] ?? 1;
        $checkout_date = $_POST['checkout_date'] ?? '';
        $booking_type = $_POST['booking_type'] ?? 'offline';
        $address = $_POST['address'] ?? '';
        $checkin_date = $_POST['checkin_date'] ?? '';
        $checkin_time = $_POST['checkin_time'] ?? '';
        $checkout_time = $_POST['checkout_time'] ?? '';
        $nid_number = $_POST['nid_number'] ?? '';
        $reference = $_POST['reference'] ?? '';
        $note = $_POST['note'] ?? '';
        
        // Meal add-ons
        $breakfast_price = $_POST['breakfast_price'] ?? 0;
        $breakfast_quantity = $_POST['breakfast_quantity'] ?? 0;
        $breakfast_total = $_POST['breakfast_total'] ?? 0;
        $lunch_price = $_POST['lunch_price'] ?? 0;
        $lunch_quantity = $_POST['lunch_quantity'] ?? 0;
        $lunch_total = $_POST['lunch_total'] ?? 0;
        $dinner_price = $_POST['dinner_price'] ?? 0;
        $dinner_quantity = $_POST['dinner_quantity'] ?? 0;
        $dinner_total = $_POST['dinner_total'] ?? 0;
        $meal_total = $_POST['meal_total'] ?? 0;
        
        // Fetch current booking details for recalculation
        $stmt = $pdo->prepare("SELECT total_amount, room_id FROM `$bookings_table` WHERE id=?");
        $stmt->execute([$booking_id]);
        $current_booking = $stmt->fetch();
        
        // Get room price for total recalculation
        $stmt = $pdo->prepare("SELECT price FROM `$rooms_table` WHERE id=?");
        $stmt->execute([$current_booking['room_id']]);
        $room = $stmt->fetch();
        $room_price = $room['price'] ?? 0;
        
        // Recalculate room total based on new dates
        $room_total = 0;
        if ($checkin_date && $checkout_date && $room_price) {
            $checkin = new DateTime($checkin_date);
            $checkout = new DateTime($checkout_date);
            $nights = $checkin->diff($checkout)->days;
            if ($nights > 0) {
                $room_total = $room_price * $nights;
            }
        }
        
        // Apply discount amount directly (not percentage)
        $room_discount_amount = $discount;
        $discounted_room_total = $room_total - $room_discount_amount;
        
        // Total Amount = Discounted Room Booking + Meal Add-ons (no discount on meals)
        $total_amount = $discounted_room_total + $meal_total;
        
        // Recalculate due amount
        $due = max(0, $total_amount - $paid);
        
        // Update booking with all details including meal add-ons and recalculated total
        $stmt = $pdo->prepare("UPDATE `$bookings_table` SET guest_name=?, guest_contact=?, status=?, paid=?, discount=?, due=?, total_amount=?, profession=?, email=?, num_guests=?, checkout_date=?, booking_type=?, address=?, checkin_date=?, checkin_time=?, checkout_time=?, note=?, reference=?, breakfast_price=?, breakfast_quantity=?, breakfast_total=?, lunch_price=?, lunch_quantity=?, lunch_total=?, dinner_price=?, dinner_quantity=?, dinner_total=?, meal_total=? WHERE id=?");
        $stmt->execute([$guest_name, $phone, $status, $paid, $discount, $due, $total_amount, $profession, $email, $num_guests, $checkout_date, $booking_type, $address, $checkin_date, $checkin_time, $checkout_time, $note, $reference, $breakfast_price, $breakfast_quantity, $breakfast_total, $lunch_price, $lunch_quantity, $lunch_total, $dinner_price, $dinner_quantity, $dinner_total, $meal_total, $booking_id]);
        
        // Update or insert guest information
        $stmt = $pdo->prepare("INSERT INTO guests (name, phone, nid, profession, email, address, no_of_guests) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE profession=?, email=?, address=?, no_of_guests=?");
        $stmt->execute([$guest_name, $phone, $nid_number, $profession, $email, $address, $num_guests, $profession, $email, $address, $num_guests]);
        
        $message = 'Booking updated successfully! All details including meal add-ons have been saved.';
        // Redirect to prevent form resubmission and duplication
        header("Location: manage_bookings.php?hotel_id=$hotel_id&message=updated");
        exit();
    } elseif (isset($_POST['delete_booking'])) {
        $booking_id = $_POST['booking_id'];
        $stmt = $pdo->prepare("DELETE FROM `$bookings_table` WHERE id=?");
        $stmt->execute([$booking_id]);
        $message = 'Booking deleted successfully!';
        // Redirect to prevent form resubmission
        header("Location: manage_bookings.php?hotel_id=$hotel_id&message=deleted");
        exit();
    }
}
// Fetch all bookings for this hotel
// Use GROUP BY to prevent duplicates from guest table joins
$bookings = $pdo->prepare("SELECT b.*, r.room_number, r.price as room_price
    FROM `$bookings_table` b 
    JOIN `$rooms_table` r ON b.room_id = r.id 
    ORDER BY b.id DESC");
$bookings->execute();
$bookings = $bookings->fetchAll();

// Old date filtering logic removed - now handled by enhanced search and filter form

// Fetch hotel info
$stmt = $pdo->prepare("SELECT name FROM hotels WHERE id = ?");
$stmt->execute([$hotel_id]);
$hotel = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Manage Bookings - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <div class="w-64 h-screen fixed top-0 left-0 pt-0 shadow-lg bg-gradient-to-b from-indigo-500 to-purple-600 text-white z-30 sidebar">
            <div class="flex items-center justify-center h-16">
                <i class="fas fa-hotel text-2xl"></i>
                <span class="ml-3 text-xl font-bold"><?php echo htmlspecialchars($hotel['name']); ?></span>
            </div>
            <nav class="mt-8">
                <a href="hotel_dashboard.php?hotel_id=<?php echo $hotel_id; ?>" class="block px-6 py-3 hover:bg-white hover:bg-opacity-20 transition-colors"><i class="fas fa-tachometer-alt mr-3"></i>Dashboard</a>
                
                 <a href="calendar.php?hotel_id=<?php echo $hotel_id; ?>" class="block px-6 py-3 hover:bg-white hover:bg-opacity-20 transition-colors"><i class="fas fa-calendar-alt mr-3"></i>Calendar</a>
                 
                 
                <?php if ($_SESSION['user_role'] === 'admin'): ?>
                <a href="manage_rooms.php?hotel_id=<?php echo $hotel_id; ?>" class="block px-6 py-3 hover:bg-white hover:bg-opacity-20 transition-colors"><i class="fas fa-bed mr-3"></i>Manage Rooms</a>
                <?php endif; ?>
                <a href="manage_bookings.php?hotel_id=<?php echo $hotel_id; ?>" class="block px-6 py-3 bg-white bg-opacity-20 border-r-4 border-white"><i class="fas fa-list mr-3"></i>Manage Bookings</a>
                <a href="pricing.php?hotel_id=<?php echo $hotel_id; ?>" class="block px-6 py-3 hover:bg-white hover:bg-opacity-20 transition-colors"><i class="fas fa-tags mr-3"></i>Pricing</a>
               
               
               
                <a href="logout.php" class="block px-6 py-3 mt-8 hover:bg-white hover:bg-opacity-20 transition-colors"><i class="fas fa-sign-out-alt mr-3"></i>Logout</a>
            </nav>
        </div>
        <!-- Main Content -->
        <div class="flex-1 p-8 ml-64 flex flex-col h-screen">
            <!-- Fixed Header Section -->
            <div class="flex-shrink-0">
                <h1 class="text-3xl font-bold mb-6 text-gray-800">Manage Bookings</h1>
                <div class="mb-6">
                    <a href="calendar.php?hotel_id=<?php echo $hotel_id; ?>" class="inline-block bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 rounded-lg shadow transition duration-200">
                        <i class="fas fa-calendar-plus mr-2"></i>Quick Booking
                    </a>
                </div>
                <!-- Booking Search and Filter Bar -->
                <div class="mb-6 bg-white p-4 rounded-lg shadow">
                <form method="post" action="" class="space-y-4">
                    <div class="flex flex-col md:flex-row items-center gap-4">
                <input type="hidden" name="hotel_id" value="<?php echo $hotel_id; ?>">
                        <input type="text" name="booking_search" placeholder="Dynamic search: Phone, NID, Room, Name, Reference (partial match)" value="<?php echo isset($_POST['booking_search']) ? htmlspecialchars($_POST['booking_search']) : ''; ?>" class="border border-gray-300 rounded px-4 py-2 w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-green-500">
                        
                        <!-- Filter by Booking Type -->
                        <select name="booking_type_filter" class="border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                            <option value="">All Booking Types</option>
                            <option value="online" <?php echo (isset($_POST['booking_type_filter']) && $_POST['booking_type_filter'] === 'online') ? 'selected' : ''; ?>>Online</option>
                            <option value="offline" <?php echo (isset($_POST['booking_type_filter']) && $_POST['booking_type_filter'] === 'offline') ? 'selected' : ''; ?>>Offline</option>
                        </select>
                        
                        <!-- Filter by Status -->
                        <select name="status_filter" class="border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                            <option value="">All Status</option>
                            <option value="active" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] === 'active') ? 'selected' : ''; ?>>Active</option>
                            <option value="cancelled" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                        
                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 rounded-lg shadow transition duration-200">
                            <i class="fas fa-search mr-2"></i>Search & Filter
                        </button>
                        
                        <button type="button" onclick="clearFilters()" class="bg-gray-500 hover:bg-gray-600 text-white font-semibold px-6 py-2 rounded-lg shadow transition duration-200">
                            <i class="fas fa-times mr-2"></i>Clear
                </button>
                    </div>
                    
                    <!-- Date Range Filter -->
                    <div class="flex flex-col md:flex-row items-center gap-4 border-t pt-4">
                        <label class="font-medium text-gray-700 flex items-center">
                            <i class="fas fa-calendar-alt mr-2"></i>Date Range:
                        </label>
                        <div class="flex items-center gap-2">
                            <label class="text-sm text-gray-600">From:</label>
                            <input type="date" name="date_from" value="<?php echo isset($_POST['date_from']) ? htmlspecialchars($_POST['date_from']) : ''; ?>" class="border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                        </div>
                        <div class="flex items-center gap-2">
                            <label class="text-sm text-gray-600">To:</label>
                            <input type="date" name="date_to" value="<?php echo isset($_POST['date_to']) ? htmlspecialchars($_POST['date_to']) : ''; ?>" class="border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                        </div>
                        <div class="flex items-center gap-2">
                            <label class="text-sm text-gray-600">Filter by:</label>
                            <select name="date_filter_type" class="border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                                <option value="checkin" <?php echo (isset($_POST['date_filter_type']) && $_POST['date_filter_type'] === 'checkin') ? 'selected' : ''; ?>>Check-in Date</option>
                                <option value="checkout" <?php echo (isset($_POST['date_filter_type']) && $_POST['date_filter_type'] === 'checkout') ? 'selected' : ''; ?>>Check-out Date</option>
                                <option value="created" <?php echo (isset($_POST['date_filter_type']) && $_POST['date_filter_type'] === 'created') ? 'selected' : ''; ?>>Booking Date</option>
                            </select>
                        </div>
                    </div>
            </form>
            </div>
            </div>
            <!-- Scrollable Content Section -->
            <div class="flex-1 overflow-auto">
            <?php
            // Enhanced filtering logic
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $search = isset($_POST['booking_search']) ? trim($_POST['booking_search']) : '';
                $booking_type_filter = isset($_POST['booking_type_filter']) ? trim($_POST['booking_type_filter']) : '';
                $status_filter = isset($_POST['status_filter']) ? trim($_POST['status_filter']) : '';
                $date_from = isset($_POST['date_from']) ? trim($_POST['date_from']) : '';
                $date_to = isset($_POST['date_to']) ? trim($_POST['date_to']) : '';
                $date_filter_type = isset($_POST['date_filter_type']) ? trim($_POST['date_filter_type']) : 'checkin';
                
                $where_conditions = [];
                $params = [];
                
                // Search condition - Dynamic search by Phone, NID, Room Number, or Guest Name (partial matching)
                if (!empty($search)) {
                    $where_conditions[] = "(b.guest_contact LIKE ? OR b.nid_number LIKE ? OR r.room_number LIKE ? OR b.guest_name LIKE ? OR b.reference LIKE ?)";
                    $params[] = "%$search%";
                    $params[] = "%$search%";
                    $params[] = "%$search%";
                    $params[] = "%$search%";
                    $params[] = "%$search%";
                }
                
                // Booking type filter
                if (!empty($booking_type_filter)) {
                    $where_conditions[] = "b.booking_type = ?";
                    $params[] = $booking_type_filter;
                }
                
                // Status filter
                if (!empty($status_filter)) {
                    $where_conditions[] = "b.status = ?";
                    $params[] = $status_filter;
                }
                
                // Date range filter
                if (!empty($date_from) && !empty($date_to)) {
                    switch ($date_filter_type) {
                        case 'checkin':
                            $where_conditions[] = "b.checkin_date BETWEEN ? AND ?";
                            $params[] = $date_from;
                            $params[] = $date_to;
                            break;
                        case 'checkout':
                            $where_conditions[] = "b.checkout_date BETWEEN ? AND ?";
                            $params[] = $date_from;
                            $params[] = $date_to;
                            break;
                        case 'created':
                            $where_conditions[] = "DATE(b.created_at) BETWEEN ? AND ?";
                            $params[] = $date_from;
                            $params[] = $date_to;
                            break;
                    }
                } elseif (!empty($date_from)) {
                    // Only from date provided
                    switch ($date_filter_type) {
                        case 'checkin':
                            $where_conditions[] = "b.checkin_date >= ?";
                            $params[] = $date_from;
                            break;
                        case 'checkout':
                            $where_conditions[] = "b.checkout_date >= ?";
                            $params[] = $date_from;
                            break;
                        case 'created':
                            $where_conditions[] = "DATE(b.created_at) >= ?";
                            $params[] = $date_from;
                            break;
                    }
                } elseif (!empty($date_to)) {
                    // Only to date provided
                    switch ($date_filter_type) {
                        case 'checkin':
                            $where_conditions[] = "b.checkin_date <= ?";
                            $params[] = $date_to;
                            break;
                        case 'checkout':
                            $where_conditions[] = "b.checkout_date <= ?";
                            $params[] = $date_to;
                            break;
                        case 'created':
                            $where_conditions[] = "DATE(b.created_at) <= ?";
                            $params[] = $date_to;
                            break;
                    }
                }
                
                $where_clause = '';
                if (!empty($where_conditions)) {
                    $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
                }
                
                $sql = "SELECT DISTINCT b.*, r.room_number, r.price as room_price 
                        FROM `$bookings_table` b JOIN `$rooms_table` r ON b.room_id = r.id $where_clause ORDER BY b.id DESC";
                $bookings = $pdo->prepare($sql);
                $bookings->execute($params);
                $bookings = $bookings->fetchAll();
            }
            ?>
            <?php if ($message): ?>
                <div class="mb-4 p-4 bg-green-100 text-green-800 rounded-lg"> <?php echo $message; ?> </div>
            <?php endif; ?>
            <!-- Download Guest History by Date Range -->
            <div class="mb-6 bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">
                    <i class="fas fa-download mr-2"></i>Download Guest History Report
                </h3>
                <form method="get" action="php/download_guest_history.php" class="flex flex-col md:flex-row items-center gap-4" onsubmit="return validateDateRange()">
                    <input type="hidden" name="hotel_id" value="<?php echo $hotel_id; ?>">
                    
                    <div class="flex items-center gap-2">
                        <label class="font-medium text-gray-700">From:</label>
                        <input type="date" name="start_date" id="start_date" required 
                               class="border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div class="flex items-center gap-2">
                        <label class="font-medium text-gray-700">To:</label>
                        <input type="date" name="end_date" id="end_date" required 
                               class="border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg shadow transition duration-200">
                        <i class="fas fa-download mr-2"></i>Download PDF Report
                    </button>
                    
                    <button type="button" onclick="setQuickDateRange('today')" class="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-lg shadow transition duration-200">
                        Today
                    </button>
                    
                    <button type="button" onclick="setQuickDateRange('week')" class="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-lg shadow transition duration-200">
                        This Week
                    </button>
                    
                    <button type="button" onclick="setQuickDateRange('month')" class="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-lg shadow transition duration-200">
                        This Month
                    </button>
                </form>
                
                <div class="mt-3 text-sm text-gray-600">
                    <i class="fas fa-info-circle mr-1"></i>
                    The report will include all bookings with check-in dates within the selected range, including guest details, financial information, and summary statistics.
                </div>
            </div>
            <!-- Booking List Table -->
            <div class="bg-white p-6 rounded-lg shadow">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-xl font-semibold">All Bookings</h2>
                    <div class="text-sm text-gray-600">
                        <i class="fas fa-info-circle mr-1"></i>
                        <span class="bg-green-50 text-green-700 px-2 py-1 rounded">Green rows = Fully paid (Due: ৳0.00)</span>
                    </div>
                </div>
                <div class="overflow-x-auto">
                <table class="min-w-full table-auto">
                    <thead>
                        <tr>
                            <th class="px-4 py-2">Booking ID</th>
                            <th class="px-4 py-2">Room</th>
                            <th class="px-4 py-2">Guest Name</th>
                            <th class="px-4 py-2">Phone</th>
                            <th class="px-4 py-2">NID</th>
                            <th class="px-4 py-2">Profession</th>
                            <th class="px-4 py-2">Email</th>
                            <th class="px-4 py-2">Guests</th>
                            <th class="px-4 py-2">Reference</th>
                            <th class="px-4 py-2">Note</th>
                            <th class="px-4 py-2">Meal Add-ons</th>
                            <th class="px-4 py-2">Check-in</th>
                            <th class="px-4 py-2">Check-out</th>
                            <th class="px-4 py-2">Type</th>
                            <th class="px-4 py-2">Total</th>
                            <th class="px-4 py-2">Discount</th>
                            <th class="px-4 py-2">Paid</th>
                            <th class="px-4 py-2">Due</th>
                            <th class="px-4 py-2">Status</th>
                            <th class="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): ?>
                        <?php 
                        $due_amount = $booking['due'] ?? 0;
                        $row_class = $due_amount == 0 ? 'border-b bg-green-50 hover:bg-green-100' : 'border-b hover:bg-gray-50';
                        ?>
                        <tr class="<?php echo $row_class; ?>" data-booking-id="<?php echo $booking['id']; ?>" data-guest-email="<?php echo htmlspecialchars($booking['email'] ?? ''); ?>">
                                <td class="px-4 py-2"><?php echo $booking['id']; ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($booking['room_number']); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($booking['guest_name']); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($booking['guest_contact']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($booking['nid_number'] ?? ''); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($booking['profession'] ?? ''); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($booking['email'] ?? ''); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($booking['num_guests'] ?? 1); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($booking['reference'] ?? ''); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($booking['note'] ?? ''); ?></td>
                            <td class="px-4 py-2">
                                <?php
                                $meal_addons = [];
                                if (!empty($booking['breakfast_quantity']) && $booking['breakfast_quantity'] > 0) {
                                    $meal_addons[] = "Breakfast ({$booking['breakfast_quantity']}x ৳" . number_format($booking['breakfast_price'] ?? 0, 2) . ")";
                                }
                                if (!empty($booking['lunch_quantity']) && $booking['lunch_quantity'] > 0) {
                                    $meal_addons[] = "Lunch ({$booking['lunch_quantity']}x ৳" . number_format($booking['lunch_price'] ?? 0, 2) . ")";
                                }
                                if (!empty($booking['dinner_quantity']) && $booking['dinner_quantity'] > 0) {
                                    $meal_addons[] = "Dinner ({$booking['dinner_quantity']}x ৳" . number_format($booking['dinner_price'] ?? 0, 2) . ")";
                                }
                                
                                // Also check for enabled flags and totals as fallback (like in PDF)
                                if (empty($meal_addons) && ($booking['breakfast_enabled'] || $booking['lunch_enabled'] || $booking['dinner_enabled'])) {
                                    if ($booking['breakfast_enabled'] && $booking['breakfast_total'] > 0) {
                                        $meal_addons[] = "Breakfast (" . ($booking['breakfast_quantity'] ?? 1) . "x ৳" . number_format($booking['breakfast_price'] ?? 0, 2) . ")";
                                    }
                                    if ($booking['lunch_enabled'] && $booking['lunch_total'] > 0) {
                                        $meal_addons[] = "Lunch (" . ($booking['lunch_quantity'] ?? 1) . "x ৳" . number_format($booking['lunch_price'] ?? 0, 2) . ")";
                                    }
                                    if ($booking['dinner_enabled'] && $booking['dinner_total'] > 0) {
                                        $meal_addons[] = "Dinner (" . ($booking['dinner_quantity'] ?? 1) . "x ৳" . number_format($booking['dinner_price'] ?? 0, 2) . ")";
                                    }
                                }
                                echo !empty($meal_addons) ? implode('<br>', $meal_addons) : '<span class="text-gray-400">None</span>';
                                ?>
                            </td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($booking['checkin_date']); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($booking['checkout_date']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($booking['booking_type'] ?? 'offline'); ?></td>
                                <td class="px-4 py-2">৳<?php echo number_format($booking['total_amount'] ?? 0, 2); ?></td>
                                <td class="px-4 py-2">৳<?php echo number_format($booking['discount'] ?? 0, 2); ?></td>
                                <td class="px-4 py-2">৳<?php echo number_format($booking['paid'] ?? 0, 2); ?></td>
                                <td class="px-4 py-2">
                                    <?php if (($booking['due'] ?? 0) == 0): ?>
                                        <span class="text-green-600 font-semibold">
                                            <i class="fas fa-check-circle mr-1"></i>৳<?php echo number_format($booking['due'] ?? 0, 2); ?>
                                        </span>
                                    <?php else: ?>
                                        ৳<?php echo number_format($booking['due'] ?? 0, 2); ?>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-2">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo $booking['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                    <?php echo ucfirst($booking['status']); ?>
                                </span>
                                </td>
                                <td class="px-4 py-2 flex space-x-2">
                                <button type="button" onclick="openEditBookingModal(<?php echo htmlspecialchars(json_encode($booking)); ?>)" class="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600" title="Edit Booking"><i class="fas fa-edit"></i></button>
                                <button type="button" onclick="downloadReceipt(<?php echo $booking['id']; ?>)" class="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600" title="Download Receipt"><i class="fas fa-download"></i></button>
                                <button type="button" onclick="sendEmailReceipt(<?php echo $booking['id']; ?>)" class="bg-purple-500 text-white px-3 py-1 rounded hover:bg-purple-600" title="Send Email"><i class="fas fa-envelope"></i></button>
                                <form method="post" style="display: inline;" onsubmit="return confirm('Delete this booking?');">
                                    <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                    <button type="submit" name="delete_booking" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600" title="Delete Booking"><i class="fas fa-trash"></i></button>
                                </form>
                                </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            </div>
            </div>
        </div>
    </div>

    <!-- Edit Booking Modal -->
    <div id="editBookingModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-screen overflow-y-auto">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-gray-800">Edit Booking</h3>
                        <button onclick="closeEditBookingModal()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                </div>
                
                <form id="editBookingForm" method="post" class="p-6">
                    <input type="hidden" id="editBookingId" name="booking_id">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Room Number</label>
                            <input type="text" id="editRoomNumber" readonly class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                        </div>
                        
                        <div class="md:col-span-2">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Check-in Date</label>
                                    <input type="date" id="editCheckinDate" name="checkin_date" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Check-in Time</label>
                                    <input type="time" id="editCheckinTime" name="checkin_time" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Check-out Date</label>
                                    <input type="date" id="editCheckoutDate" name="checkout_date" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Check-out Time</label>
                                    <input type="time" id="editCheckoutTime" name="checkout_time" value="11:00" readonly class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                                    <small class="text-gray-500">Fixed at 11:00 AM</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Meal Add-ons Section -->
                        <div class="md:col-span-2">
                            <h4 class="text-lg font-medium text-gray-800 mb-4">Meal Add-ons</h4>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <!-- Breakfast -->
                                <div class="border border-gray-200 rounded-lg p-4">
                                    <div class="flex items-center mb-3">
                                        <input type="checkbox" id="editBreakfastCheckbox" name="breakfast_enabled" class="mr-2">
                                        <label for="editBreakfastCheckbox" class="font-medium text-gray-700">Breakfast</label>
                                    </div>
                                    <div class="space-y-2">
                                        <div>
                                            <label class="block text-sm text-gray-600">Price (BDT)</label>
                                            <input type="number" id="editBreakfastPrice" name="breakfast_price" min="0" step="0.01" value="0" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600">Quantity</label>
                                            <input type="number" id="editBreakfastQuantity" name="breakfast_quantity" min="0" value="0" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600">Total</label>
                                            <input type="number" id="editBreakfastTotal" name="breakfast_total" readonly class="w-full px-2 py-1 border border-gray-300 rounded text-sm bg-gray-50">
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Lunch -->
                                <div class="border border-gray-200 rounded-lg p-4">
                                    <div class="flex items-center mb-3">
                                        <input type="checkbox" id="editLunchCheckbox" name="lunch_enabled" class="mr-2">
                                        <label for="editLunchCheckbox" class="font-medium text-gray-700">Lunch</label>
                                    </div>
                                    <div class="space-y-2">
                                        <div>
                                            <label class="block text-sm text-gray-600">Price (BDT)</label>
                                            <input type="number" id="editLunchPrice" name="lunch_price" min="0" step="0.01" value="0" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600">Quantity</label>
                                            <input type="number" id="editLunchQuantity" name="lunch_quantity" min="0" value="0" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600">Total</label>
                                            <input type="number" id="editLunchTotal" name="lunch_total" readonly class="w-full px-2 py-1 border border-gray-300 rounded text-sm bg-gray-50">
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Dinner -->
                                <div class="border border-gray-200 rounded-lg p-4">
                                    <div class="flex items-center mb-3">
                                        <input type="checkbox" id="editDinnerCheckbox" name="dinner_enabled" class="mr-2">
                                        <label for="editDinnerCheckbox" class="font-medium text-gray-700">Dinner</label>
                                    </div>
                                    <div class="space-y-2">
                                        <div>
                                            <label class="block text-sm text-gray-600">Price (BDT)</label>
                                            <input type="number" id="editDinnerPrice" name="dinner_price" min="0" step="0.01" value="0" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600">Quantity</label>
                                            <input type="number" id="editDinnerQuantity" name="dinner_quantity" min="0" value="0" class="w-full px-2 py-1 border border-gray-300 rounded text-sm">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600">Total</label>
                                            <input type="number" id="editDinnerTotal" name="dinner_total" readonly class="w-full px-2 py-1 border border-gray-300 rounded text-sm bg-gray-50">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Total Meal Add-ons (BDT)</label>
                                <input type="number" id="editMealTotal" name="meal_total" readonly class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Total Amount (BDT)</label>
                            <input type="number" id="editTotalAmount" name="total_amount" readonly class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Discount Amount (BDT)</label>
                            <input type="number" id="editDiscountPercent" name="discount" min="0" step="0.01" value="0" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Paid Amount (BDT)</label>
                            <input type="number" id="editPaidAmount" name="paid" min="0" step="0.01" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Due Amount (BDT)</label>
                            <input type="number" id="editDueAmount" name="due" readonly class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Number of Guests</label>
                            <input type="number" id="editNumGuests" name="num_guests" min="1" max="10" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                        </div>
                    </div>
                    
                    <div class="mt-6 space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Guest Name</label>
                            <input type="text" id="editGuestName" name="guest_name" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Reference (Optional)</label>
                                <input type="text" id="editReference" name="reference" placeholder="Reference number or code" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Note (Optional)</label>
                                <textarea id="editNote" name="note" placeholder="Additional notes or special requests" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg"></textarea>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">NID Number</label>
                                <input type="text" id="editNidNumber" name="nid_number" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Profession</label>
                                <input type="text" id="editProfession" name="profession" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                                <input type="email" id="editEmail" name="email" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                                <input type="tel" id="editPhone" name="phone" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Address</label>
                            <input type="text" id="editAddress" name="address" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                        </div>
                        
                        <div class="mt-4">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Booking Type</label>
                            <select id="editBookingType" name="booking_type" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                                <option value="online">Online</option>
                                <option value="offline">Offline</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                            <select id="editStatus" name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                                <option value="active">Active</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mt-6 flex justify-end space-x-3">
                        <button type="button" onclick="closeEditBookingModal()" class="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors">
                            Cancel
                        </button>
                        <button type="submit" name="edit_booking" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                            Update Booking
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Clear filters function
        function clearFilters() {
            document.querySelector('input[name="booking_search"]').value = '';
            document.querySelector('select[name="booking_type_filter"]').value = '';
            document.querySelector('select[name="status_filter"]').value = '';
            document.querySelector('input[name="date_from"]').value = '';
            document.querySelector('input[name="date_to"]').value = '';
            document.querySelector('select[name="date_filter_type"]').value = 'checkin';
            document.querySelector('form').submit();
        }

        // Download receipt function
        function downloadReceipt(bookingId) {
            window.open(`php/generate_booking_pdf.php?booking_id=${bookingId}&hotel_id=<?php echo $hotel_id; ?>`, '_blank');
        }

        // Send email receipt function
        function sendEmailReceipt(bookingId) {
            if (confirm('Send booking receipt via email?')) {
                // Get the guest email from the booking data
                const bookingRow = document.querySelector(`tr[data-booking-id="${bookingId}"]`);
                const guestEmail = bookingRow ? bookingRow.getAttribute('data-guest-email') : '';
                
                if (!guestEmail) {
                    alert('Guest email not found. Please add email address to the booking first.');
                    return;
                }
                
                // Send JSON request to email PDF
                fetch('php/email_booking_pdf.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        booking_id: bookingId,
                        hotel_id: <?php echo $hotel_id; ?>,
                        email: guestEmail
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('PDF sent successfully to ' + guestEmail);
                    } else {
                        alert('Failed to send PDF: ' + (data.message || 'Unknown error'));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Failed to send PDF. Please try again.');
                });
            }
        }

        // Edit Booking Modal Functions
        function openEditBookingModal(bookingData) {
            // Populate form fields with booking data
            document.getElementById('editBookingId').value = bookingData.id;
            document.getElementById('editRoomNumber').value = bookingData.room_number;
            document.getElementById('editGuestName').value = bookingData.guest_name;
            document.getElementById('editPhone').value = bookingData.guest_contact;
            document.getElementById('editNidNumber').value = bookingData.nid_number || '';
            document.getElementById('editProfession').value = bookingData.profession || '';
            document.getElementById('editEmail').value = bookingData.email || '';
            document.getElementById('editNumGuests').value = bookingData.num_guests || 1;
            document.getElementById('editCheckinDate').value = bookingData.checkin_date;
            document.getElementById('editCheckinTime').value = bookingData.checkin_time || '';
            document.getElementById('editCheckoutDate').value = bookingData.checkout_date;
            document.getElementById('editCheckoutTime').value = bookingData.checkout_time || '11:00';
            document.getElementById('editBookingType').value = bookingData.booking_type || 'offline';
            document.getElementById('editStatus').value = bookingData.status || 'active';
            document.getElementById('editDiscountPercent').value = bookingData.discount || 0;
            document.getElementById('editPaidAmount').value = bookingData.paid || 0;
            document.getElementById('editAddress').value = bookingData.address || '';
            document.getElementById('editReference').value = bookingData.reference || '';
            document.getElementById('editNote').value = bookingData.note || '';
            
            // Set room price for total calculation
            window.editRoomPrice = bookingData.room_price || 0;
            
            // Populate meal data
            document.getElementById('editBreakfastPrice').value = bookingData.breakfast_price || 0;
            document.getElementById('editBreakfastQuantity').value = bookingData.breakfast_quantity || 0;
            document.getElementById('editBreakfastTotal').value = bookingData.breakfast_total || 0;
            document.getElementById('editLunchPrice').value = bookingData.lunch_price || 0;
            document.getElementById('editLunchQuantity').value = bookingData.lunch_quantity || 0;
            document.getElementById('editLunchTotal').value = bookingData.lunch_total || 0;
            document.getElementById('editDinnerPrice').value = bookingData.dinner_price || 0;
            document.getElementById('editDinnerQuantity').value = bookingData.dinner_quantity || 0;
            document.getElementById('editDinnerTotal').value = bookingData.dinner_total || 0;
            document.getElementById('editMealTotal').value = bookingData.meal_total || 0;
            
            // Set meal checkboxes
            document.getElementById('editBreakfastCheckbox').checked = (bookingData.breakfast_price > 0 || bookingData.breakfast_quantity > 0);
            document.getElementById('editLunchCheckbox').checked = (bookingData.lunch_price > 0 || bookingData.lunch_quantity > 0);
            document.getElementById('editDinnerCheckbox').checked = (bookingData.dinner_price > 0 || bookingData.dinner_quantity > 0);
            
            // Enable/disable meal fields based on checkboxes
            updateEditMealFields();
            
            // Recalculate total amount to include meals
            calculateEditTotalAmount();
            
            // Show modal
            document.getElementById('editBookingModal').classList.remove('hidden');
        }
        
        function closeEditBookingModal() {
            document.getElementById('editBookingModal').classList.add('hidden');
        }
        
        function updateEditMealFields() {
            const breakfastEnabled = document.getElementById('editBreakfastCheckbox').checked;
            const lunchEnabled = document.getElementById('editLunchCheckbox').checked;
            const dinnerEnabled = document.getElementById('editDinnerCheckbox').checked;
            
            // Breakfast fields
            document.getElementById('editBreakfastPrice').disabled = !breakfastEnabled;
            document.getElementById('editBreakfastQuantity').disabled = !breakfastEnabled;
            if (!breakfastEnabled) {
                document.getElementById('editBreakfastPrice').classList.add('bg-gray-50');
                document.getElementById('editBreakfastQuantity').classList.add('bg-gray-50');
            } else {
                document.getElementById('editBreakfastPrice').classList.remove('bg-gray-50');
                document.getElementById('editBreakfastQuantity').classList.remove('bg-gray-50');
            }
            
            // Lunch fields
            document.getElementById('editLunchPrice').disabled = !lunchEnabled;
            document.getElementById('editLunchQuantity').disabled = !lunchEnabled;
            if (!lunchEnabled) {
                document.getElementById('editLunchPrice').classList.add('bg-gray-50');
                document.getElementById('editLunchQuantity').classList.add('bg-gray-50');
            } else {
                document.getElementById('editLunchPrice').classList.remove('bg-gray-50');
                document.getElementById('editLunchQuantity').classList.remove('bg-gray-50');
            }
            
            // Dinner fields
            document.getElementById('editDinnerPrice').disabled = !dinnerEnabled;
            document.getElementById('editDinnerQuantity').disabled = !dinnerEnabled;
            if (!dinnerEnabled) {
                document.getElementById('editDinnerPrice').classList.add('bg-gray-50');
                document.getElementById('editDinnerQuantity').classList.add('bg-gray-50');
            } else {
                document.getElementById('editDinnerPrice').classList.remove('bg-gray-50');
                document.getElementById('editDinnerQuantity').classList.remove('bg-gray-50');
            }
            
            calculateEditMealTotals();
        }
        
        function calculateEditMealTotals() {
            // Calculate individual meal totals
            const breakfastPrice = parseFloat(document.getElementById('editBreakfastPrice').value) || 0;
            const breakfastQuantity = parseInt(document.getElementById('editBreakfastQuantity').value) || 0;
            const breakfastTotal = breakfastPrice * breakfastQuantity;
            document.getElementById('editBreakfastTotal').value = breakfastTotal.toFixed(2);
            
            const lunchPrice = parseFloat(document.getElementById('editLunchPrice').value) || 0;
            const lunchQuantity = parseInt(document.getElementById('editLunchQuantity').value) || 0;
            const lunchTotal = lunchPrice * lunchQuantity;
            document.getElementById('editLunchTotal').value = lunchTotal.toFixed(2);
            
            const dinnerPrice = parseFloat(document.getElementById('editDinnerPrice').value) || 0;
            const dinnerQuantity = parseInt(document.getElementById('editDinnerQuantity').value) || 0;
            const dinnerTotal = dinnerPrice * dinnerQuantity;
            document.getElementById('editDinnerTotal').value = dinnerTotal.toFixed(2);
            
            // Calculate total meal amount
            const mealTotal = breakfastTotal + lunchTotal + dinnerTotal;
            document.getElementById('editMealTotal').value = mealTotal.toFixed(2);
            
            // Update total amount (which now includes meals)
            calculateEditTotalAmount();
        }
        
        function calculateEditTotalAmount() {
            const checkin = document.getElementById('editCheckinDate').value;
            const checkout = document.getElementById('editCheckoutDate').value;
            const roomPrice = window.editRoomPrice || 0;
            let roomTotal = 0;
            
            if (checkin && checkout && roomPrice) {
                const d1 = new Date(checkin);
                const d2 = new Date(checkout);
                const nights = (d2 - d1) / (1000 * 60 * 60 * 24);
                if (nights > 0) {
                    roomTotal = roomPrice * nights;
                }
            }
            
            // Calculate meal total
            const mealTotal = parseFloat(document.getElementById('editMealTotal').value) || 0;
            
            // Apply discount amount directly (not percentage)
            const discount = parseFloat(document.getElementById('editDiscountPercent').value) || 0;
            const roomDiscountAmount = discount;
            const discountedRoomTotal = roomTotal - roomDiscountAmount;
            
            // Total Amount = Discounted Room Booking + Meal Add-ons (no discount on meals)
            const totalAmount = discountedRoomTotal + mealTotal;
            
            document.getElementById('editTotalAmount').value = totalAmount.toFixed(2);
            
            // Recalculate due amount after total change
            calculateEditDueAmount();
        }
        
        function calculateEditDueAmount() {
            const total = parseFloat(document.getElementById('editTotalAmount').value) || 0;
            const paid = parseFloat(document.getElementById('editPaidAmount').value) || 0;
            
            // Total Amount already includes discount, so calculate due directly
            const due = Math.max(0, total - paid);
            
            document.getElementById('editDueAmount').value = due.toFixed(2);
        }
        
        // Add event listeners for edit modal
        document.addEventListener('DOMContentLoaded', function() {
            // Meal checkbox event listeners
            document.getElementById('editBreakfastCheckbox').addEventListener('change', updateEditMealFields);
            document.getElementById('editLunchCheckbox').addEventListener('change', updateEditMealFields);
            document.getElementById('editDinnerCheckbox').addEventListener('change', updateEditMealFields);
            
            // Meal price and quantity event listeners
            document.getElementById('editBreakfastPrice').addEventListener('input', calculateEditMealTotals);
            document.getElementById('editBreakfastQuantity').addEventListener('input', calculateEditMealTotals);
            document.getElementById('editLunchPrice').addEventListener('input', calculateEditMealTotals);
            document.getElementById('editLunchQuantity').addEventListener('input', calculateEditMealTotals);
            document.getElementById('editDinnerPrice').addEventListener('input', calculateEditMealTotals);
            document.getElementById('editDinnerQuantity').addEventListener('input', calculateEditMealTotals);
            
            // Date change event listeners for total recalculation
            document.getElementById('editCheckinDate').addEventListener('change', calculateEditTotalAmount);
            document.getElementById('editCheckoutDate').addEventListener('change', calculateEditTotalAmount);
            
            // Financial fields event listeners
            document.getElementById('editDiscountPercent').addEventListener('input', calculateEditTotalAmount);
            document.getElementById('editPaidAmount').addEventListener('input', calculateEditDueAmount);
        });

        // Show success message without auto-refresh
        <?php if ($message): ?>
        // Remove auto-refresh to prevent duplication issues
        // setTimeout(function() {
        //     location.reload();
        // }, 2000);
        <?php endif; ?>

        // Date range validation function
        function validateDateRange() {
            const startDate = document.getElementById('start_date').value;
            const endDate = document.getElementById('end_date').value;
            
            if (!startDate || !endDate) {
                alert('Please select both start and end dates.');
                return false;
            }
            
            if (startDate > endDate) {
                alert('Start date cannot be after end date.');
                return false;
            }
            
            return true;
        }

        // Quick date range selection functions
        function setQuickDateRange(range) {
            const today = new Date();
            let startDate, endDate;
            
            switch(range) {
                case 'today':
                    startDate = today.toISOString().split('T')[0];
                    endDate = startDate;
                    break;
                case 'week':
                    const startOfWeek = new Date(today);
                    startOfWeek.setDate(today.getDate() - today.getDay());
                    startDate = startOfWeek.toISOString().split('T')[0];
                    endDate = today.toISOString().split('T')[0];
                    break;
                case 'month':
                    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
                    startDate = startOfMonth.toISOString().split('T')[0];
                    endDate = today.toISOString().split('T')[0];
                    break;
                default:
                    return;
            }
            
            document.getElementById('start_date').value = startDate;
            document.getElementById('end_date').value = endDate;
        }

        // Enhanced search functionality
        function enhanceSearch() {
            const searchInput = document.querySelector('input[name="booking_search"]');
            const searchForm = document.querySelector('form');
            
            if (searchInput) {
                // Add search tips
                searchInput.addEventListener('focus', function() {
                    this.title = 'Search by: Phone (0160), NID (TEMP), Name (Saidul), Room (103), Reference (JOY)';
                });
                
                // Show search suggestions on input
                searchInput.addEventListener('input', function() {
                    const value = this.value.trim();
                    if (value.length >= 2) {
                        // Add visual feedback
                        this.style.borderColor = '#10B981'; // Green border for active search
                    } else {
                        this.style.borderColor = '#D1D5DB'; // Default border
                    }
                });
                
                // Clear search styling when empty
                searchInput.addEventListener('blur', function() {
                    if (!this.value.trim()) {
                        this.style.borderColor = '#D1D5DB';
                    }
                });
            }
            
            // Add search result counter
            const resultCount = document.querySelectorAll('tbody tr').length;
            if (resultCount > 0) {
                const header = document.querySelector('.text-xl.font-semibold');
                if (header) {
                    header.innerHTML = `All Bookings <span class="text-sm text-gray-500">(${resultCount} found)</span>`;
                }
            }
        }
        
        // Initialize enhanced search on page load
        document.addEventListener('DOMContentLoaded', function() {
            enhanceSearch();
        });
    </script>
</body>
</html> 