<?php
// Simulate the exact pricing page logic
$hotel_id = 1;

// Connect to database using XAMPP
$host = '127.0.0.1';
$db   = 'hotel';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

echo "<h1>Pricing Page Logic Test</h1>";

// Step 1: Get rooms (exact same query as pricing page)
$rooms_table = "rooms_hotel_{$hotel_id}";
$stmt = $pdo->prepare("
    SELECT DISTINCT r.*, rc.name as category_name, rc.description as category_description 
    FROM `$rooms_table` r 
    LEFT JOIN room_categories rc ON r.category = rc.name AND rc.hotel_id = ? 
    ORDER BY r.room_number, r.id
");
$stmt->execute([$hotel_id]);
$rooms = $stmt->fetchAll();

echo "<h2>Step 1: Rooms Retrieved</h2>";
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Room Number</th><th>Status</th><th>Category</th></tr>";
foreach ($rooms as $room) {
    echo "<tr>";
    echo "<td>{$room['id']}</td>";
    echo "<td>{$room['room_number']}</td>";
    echo "<td>{$room['status']}</td>";
    echo "<td>{$room['category']}</td>";
    echo "</tr>";
}
echo "</table>";

// Step 2: Get booking status (exact same query as pricing page)
$bookings_table = "bookings_hotel_{$hotel_id}";
$stmt = $pdo->prepare("
    SELECT room_id, COUNT(*) as booking_count 
    FROM `$bookings_table` 
    WHERE status = 'active' 
    GROUP BY room_id
");
$stmt->execute();
$room_bookings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

echo "<h2>Step 2: Room Bookings</h2>";
echo "<table border='1'>";
echo "<tr><th>Room ID</th><th>Booking Count</th></tr>";
foreach ($room_bookings as $room_id => $booking_count) {
    echo "<tr>";
    echo "<td>{$room_id}</td>";
    echo "<td>{$booking_count}</td>";
    echo "</tr>";
}
echo "</table>";

// Step 3: Enhance rooms data (exact same logic as pricing page)
echo "<h2>Step 3: Enhanced Room Data</h2>";
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Room Number</th><th>Original Status</th><th>Has Bookings</th><th>Is Booked (Calculated)</th><th>Would Show As</th></tr>";

$unavailable_count = 0;
$available_count = 0;

foreach ($rooms as $room) {
    $has_bookings = isset($room_bookings[$room['id']]) && $room_bookings[$room['id']] > 0;
    $is_booked = $has_bookings;
    
    if ($is_booked) {
        $unavailable_count++;
        $display_status = "Unavailable";
    } else {
        $available_count++;
        $display_status = "Available";
    }
    
    echo "<tr>";
    echo "<td>{$room['id']}</td>";
    echo "<td>{$room['room_number']}</td>";
    echo "<td>{$room['status']}</td>";
    echo "<td>" . ($has_bookings ? 'Yes' : 'No') . "</td>";
    echo "<td>" . ($is_booked ? 'Yes' : 'No') . "</td>";
    echo "<td>{$display_status}</td>";
    echo "</tr>";
}
echo "</table>";

echo "<h2>Summary:</h2>";
echo "<p>Total Rooms: " . count($rooms) . "</p>";
echo "<p>Rooms that should show as Unavailable: {$unavailable_count}</p>";
echo "<p>Rooms that should show as Available: {$available_count}</p>";

// Let's also check if there are any rooms with bookings that are not in the rooms list
echo "<h2>Cross-check:</h2>";
$booked_room_ids = array_keys($room_bookings);
$room_ids = array_column($rooms, 'id');

echo "<p>Room IDs with bookings: " . implode(', ', $booked_room_ids) . "</p>";
echo "<p>Room IDs in rooms table: " . implode(', ', $room_ids) . "</p>";

$missing_rooms = array_diff($booked_room_ids, $room_ids);
if (!empty($missing_rooms)) {
    echo "<p style='color: red;'>WARNING: Rooms with bookings but not in rooms table: " . implode(', ', $missing_rooms) . "</p>";
} else {
    echo "<p style='color: green;'>✓ All rooms with bookings are in the rooms table</p>";
}
?> 