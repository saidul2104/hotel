<?php
// Check what the actual pricing page is showing
session_start();

// Simulate a logged-in user session
$_SESSION['user_id'] = 1;
$_SESSION['user_name'] = 'Admin';
$_SESSION['user_role'] = 'admin';

// Include the pricing page logic
$hotel_id = 1;

// Connect to database
$host = '127.0.0.1';
$db   = 'hotel';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

echo "<h1>Actual Pricing Page Room Status</h1>";

// Get rooms (same as pricing page)
$rooms_table = "rooms_hotel_{$hotel_id}";
$stmt = $pdo->prepare("
    SELECT DISTINCT r.*, rc.name as category_name, rc.description as category_description 
    FROM `$rooms_table` r 
    LEFT JOIN room_categories rc ON r.category = rc.name AND rc.hotel_id = ? 
    ORDER BY r.room_number, r.id
");
$stmt->execute([$hotel_id]);
$rooms = $stmt->fetchAll();

echo "<h2>Debug: All Rooms Retrieved</h2>";
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Room Number</th><th>Category</th><th>Category Name</th></tr>";
foreach ($rooms as $room) {
    echo "<tr>";
    echo "<td>{$room['id']}</td>";
    echo "<td>{$room['room_number']}</td>";
    echo "<td>{$room['category']}</td>";
    echo "<td>{$room['category_name']}</td>";
    echo "</tr>";
}
echo "</table>";

// Get booking status (same as pricing page)
$bookings_table = "bookings_hotel_{$hotel_id}";
$stmt = $pdo->prepare("
    SELECT room_id, COUNT(*) as booking_count 
    FROM `$bookings_table` 
    WHERE status = 'active' 
    GROUP BY room_id
");
$stmt->execute();
$room_bookings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

echo "<h2>Debug: Room Bookings</h2>";
echo "<table border='1'>";
echo "<tr><th>Room ID</th><th>Booking Count</th></tr>";
foreach ($room_bookings as $room_id => $booking_count) {
    echo "<tr>";
    echo "<td>{$room_id}</td>";
    echo "<td>{$booking_count}</td>";
    echo "</tr>";
}
echo "</table>";

// Enhance rooms data (same as pricing page)
foreach ($rooms as &$room) {
    $room['is_booked'] = isset($room_bookings[$room['id']]) && $room_bookings[$room['id']] > 0;
    $room['status'] = $room['is_booked'] ? 'booked' : 'available';
}

echo "<h2>Debug: Enhanced Rooms Data</h2>";
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Room Number</th><th>Is Booked</th><th>Status</th></tr>";
foreach ($rooms as $room) {
    echo "<tr>";
    echo "<td>{$room['id']}</td>";
    echo "<td>{$room['room_number']}</td>";
    echo "<td>" . ($room['is_booked'] ? 'Yes' : 'No') . "</td>";
    echo "<td>{$room['status']}</td>";
    echo "</tr>";
}
echo "</table>";

echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr style='background-color: #f3f4f6;'>";
echo "<th style='padding: 8px; border: 1px solid #d1d5db;'>Room Number</th>";
echo "<th style='padding: 8px; border: 1px solid #d1d5db;'>Category</th>";
echo "<th style='padding: 8px; border: 1px solid #d1d5db;'>Database Status</th>";
echo "<th style='padding: 8px; border: 1px solid #d1d5db;'>Has Active Bookings</th>";
echo "<th style='padding: 8px; border: 1px solid #d1d5db;'>Calculated Status</th>";
echo "<th style='padding: 8px; border: 1px solid #d1d5db;'>Should Display As</th>";
echo "</tr>";

$unavailable_count = 0;
$available_count = 0;
$processed_rooms = [];

foreach ($rooms as $room) {
    $has_bookings = isset($room_bookings[$room['id']]) && $room_bookings[$room['id']] > 0;
    $is_booked = $has_bookings;
    
    if ($is_booked) {
        $unavailable_count++;
        $display_status = "Unavailable";
        $row_color = "#fef2f2";
        $status_color = "#dc2626";
    } else {
        $available_count++;
        $display_status = "Available";
        $row_color = "#f0fdf4";
        $status_color = "#16a34a";
    }
    
    $processed_rooms[] = $room['room_number'];
    
    echo "<tr style='background-color: {$row_color};'>";
    echo "<td style='padding: 8px; border: 1px solid #d1d5db;'>{$room['room_number']}</td>";
    echo "<td style='padding: 8px; border: 1px solid #d1d5db;'>{$room['category']}</td>";
    echo "<td style='padding: 8px; border: 1px solid #d1d5db;'>{$room['status']}</td>";
    echo "<td style='padding: 8px; border: 1px solid #d1d5db;'>" . ($has_bookings ? 'Yes' : 'No') . "</td>";
    echo "<td style='padding: 8px; border: 1px solid #d1d5db;'>" . ($is_booked ? 'booked' : 'available') . "</td>";
    echo "<td style='padding: 8px; border: 1px solid #d1d5db; color: {$status_color}; font-weight: bold;'>{$display_status}</td>";
    echo "</tr>";
}
echo "</table>";

echo "<h2>Summary:</h2>";
echo "<p><strong>Total Rooms:</strong> " . count($rooms) . "</p>";
echo "<p><strong>Rooms that should show as Unavailable:</strong> {$unavailable_count}</p>";
echo "<p><strong>Rooms that should show as Available:</strong> {$available_count}</p>";
echo "<p><strong>Processed Room Numbers:</strong> " . implode(', ', $processed_rooms) . "</p>";

if ($unavailable_count == 4) {
    echo "<p style='color: green; font-weight: bold;'>✓ The pricing page should be showing 4 unavailable rooms</p>";
    echo "<p>If you're only seeing 3, try refreshing the page with Ctrl+F5 to clear the cache.</p>";
} else {
    echo "<p style='color: red; font-weight: bold;'>✗ There's a discrepancy in the logic</p>";
    echo "<p>Expected 4 unavailable rooms, but found {$unavailable_count}</p>";
}
?> 