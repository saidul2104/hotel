<?php
header('Content-Type: application/json');
require_once 'database/config.php';

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid input data');
    }
    
    $room_id = $input['room_id'] ?? null;
    $checkin_date = $input['checkin_date'] ?? null;
    $checkout_date = $input['checkout_date'] ?? null;
    $hotel_id = $input['hotel_id'] ?? null;
    
    if (!$room_id || !$checkin_date || !$checkout_date || !$hotel_id) {
        throw new Exception('Missing required parameters');
    }
    
    $bookings_table = "bookings_hotel_{$hotel_id}";
    
    // Check for conflicting bookings with time-based logic
    // Check-out time: 10:50 AM, Check-in time: After 11:00 AM
    // So same-day turnover is possible - if checkout date = checkin date, it's allowed
    $stmt = $pdo->prepare("
        SELECT id, guest_name, checkin_date, checkout_date 
        FROM {$bookings_table} 
        WHERE room_id = ? 
        AND status IN ('active', 'checked_in') 
        AND (
            (checkin_date < ? AND checkout_date > ?) OR
            (checkin_date < ? AND checkout_date > ?)
        )
    ");
    
    $stmt->execute([$room_id, $checkin_date, $checkin_date, $checkout_date, $checkin_date]);
    $conflicts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $response = [
        'success' => true,
        'available' => empty($conflicts),
        'conflicts' => $conflicts
    ];
    
    echo json_encode($response);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?> 