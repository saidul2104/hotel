<?php
// Sample hotel creation script
require_once 'database/config.php';

echo "<h1>Creating Sample Hotel</h1>";

try {
    // Check if admin user exists
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? AND role = ?');
    $stmt->execute(['admin@neemshotel.com', 'admin']);
    $admin = $stmt->fetch();
    
    if (!$admin) {
        echo "<p style='color: red;'>❌ Admin user not found. Please run setup_database.php first.</p>";
        exit();
    }
    
    $admin_id = $admin['id'];
    
    // Check if hotel already exists
    $stmt = $pdo->prepare('SELECT id FROM hotels WHERE name = ?');
    $stmt->execute(['Sample Hotel']);
    $existing_hotel = $stmt->fetch();
    
    if ($existing_hotel) {
        echo "<p>✅ Sample hotel already exists (ID: {$existing_hotel['id']})</p>";
        $hotel_id = $existing_hotel['id'];
    } else {
        // Create sample hotel
        $stmt = $pdo->prepare('INSERT INTO hotels (name, address, phone, email, owner_id) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute(['Sample Hotel', '123 Main Street, Dhaka', '+880 1234-567890', 'info@samplehotel.com', $admin_id]);
        $hotel_id = $pdo->lastInsertId();
        echo "<p>✅ Sample hotel created successfully (ID: $hotel_id)</p>";
    }
    
    // Create rooms table for this hotel
    $rooms_table = "rooms_hotel_{$hotel_id}";
    $pdo->exec("CREATE TABLE IF NOT EXISTS `$rooms_table` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        room_number VARCHAR(50) NOT NULL,
        category VARCHAR(100),
        description TEXT,
        price DECIMAL(10,2),
        status VARCHAR(50) DEFAULT 'available',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(room_number)
    ) ENGINE=InnoDB");
    echo "<p>✅ Rooms table created: $rooms_table</p>";
    
    // Create bookings table for this hotel
    $bookings_table = "bookings_hotel_{$hotel_id}";
    $pdo->exec("CREATE TABLE IF NOT EXISTS `$bookings_table` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        room_id INT NOT NULL,
        guest_name VARCHAR(255),
        guest_contact VARCHAR(255),
        checkin_date DATE,
        checkout_date DATE,
        checkin_time TIME,
        checkout_time TIME,
        total_amount DECIMAL(10,2),
        discount DECIMAL(10,2) DEFAULT 0.00,
        paid DECIMAL(10,2) DEFAULT 0.00,
        due DECIMAL(10,2) DEFAULT 0.00,
        status VARCHAR(50) DEFAULT 'active',
        booking_type VARCHAR(50),
        reference VARCHAR(100),
        note TEXT,
        breakfast_price DECIMAL(10,2) DEFAULT 0.00,
        breakfast_quantity INT DEFAULT 0,
        breakfast_total DECIMAL(10,2) DEFAULT 0.00,
        lunch_price DECIMAL(10,2) DEFAULT 0.00,
        lunch_quantity INT DEFAULT 0,
        lunch_total DECIMAL(10,2) DEFAULT 0.00,
        dinner_price DECIMAL(10,2) DEFAULT 0.00,
        dinner_quantity INT DEFAULT 0,
        dinner_total DECIMAL(10,2) DEFAULT 0.00,
        meal_total DECIMAL(10,2) DEFAULT 0.00,
        breakfast_enabled BOOLEAN DEFAULT FALSE,
        lunch_enabled BOOLEAN DEFAULT FALSE,
        dinner_enabled BOOLEAN DEFAULT FALSE,
        nid_number VARCHAR(50),
        profession VARCHAR(50),
        email VARCHAR(100),
        address TEXT,
        num_guests INT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (room_id) REFERENCES `$rooms_table`(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
    echo "<p>✅ Bookings table created: $bookings_table</p>";
    
    // Add some sample rooms
    $sample_rooms = [
        ['101', 'Standard', 'Comfortable standard room with basic amenities', 2500.00],
        ['102', 'Standard', 'Comfortable standard room with basic amenities', 2500.00],
        ['201', 'Deluxe', 'Spacious deluxe room with premium amenities', 3500.00],
        ['202', 'Deluxe', 'Spacious deluxe room with premium amenities', 3500.00],
        ['301', 'Suite', 'Luxury suite with separate living area', 5000.00]
    ];
    
    foreach ($sample_rooms as $room) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO `$rooms_table` (room_number, category, description, price) VALUES (?, ?, ?, ?)");
        $stmt->execute($room);
    }
    echo "<p>✅ Sample rooms added</p>";
    
    echo "<h2>🎉 Sample hotel setup completed successfully!</h2>";
    echo "<p><strong>Hotel ID:</strong> $hotel_id</p>";
    echo "<p><strong>Hotel Name:</strong> Sample Hotel</p>";
    echo "<p><a href='dashboard.php' style='background: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Dashboard</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Database error: " . $e->getMessage() . "</p>";
}
?> 