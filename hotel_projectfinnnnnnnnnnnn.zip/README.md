# Hotel Management System

A comprehensive hotel management system built with PHP, MySQL, and modern web technologies.

## Features

- **Multi-hotel Management**: Support for multiple hotels with individual dashboards
- **Room Management**: Add, edit, and manage room categories and availability
- **Booking System**: Complete booking workflow with check-in/check-out
- **Guest Management**: Store and manage guest information
- **Revenue Tracking**: Daily, monthly, and yearly revenue reports
- **PDF Generation**: Generate booking receipts and reports
- **Email Notifications**: Send booking confirmations via email
- **Admin Dashboard**: Comprehensive admin panel for system management

## Prerequisites

Before running this project, make sure you have the following installed:

1. **XAMPP** or **WAMP** (for Windows)
   - Apache Web Server
   - MySQL Database
   - PHP 7.4 or higher

2. **Composer** (for PHP dependencies)

## Installation Steps

### 1. Clone/Download the Project

Place the project files in your web server directory:
- For XAMPP: `C:\xampp\htdocs\hotel-management\`
- For WAMP: `C:\wamp64\www\hotel-management\`

### 2. Start Your Web Server

1. Start XAMPP/WAMP
2. Start Apache and MySQL services
3. Make sure both services are running (green status)

### 3. Set Up the Database

1. Open your web browser and navigate to:
   ```
   http://localhost/hotel-management/setup_database.php
   ```

2. This will automatically:
   - Create the database `neemshotel_db`
   - Create all required tables
   - Set up foreign key relationships
   - Create an admin user

3. You should see a success message with admin credentials:
   - **Email**: admin@neemshotel.com
   - **Password**: admin123

### 4. Install PHP Dependencies (if needed)

If the project uses Composer dependencies, run:
```bash
composer install
```

### 5. Access the Application

1. Open your web browser
2. Navigate to: `http://localhost/hotel-management/`
3. You'll be redirected to the login page
4. Use the admin credentials to log in:
   - Email: admin@neemshotel.com
   - Password: admin123

## Database Configuration

The database configuration is located in `database/config.php`:

```php
$host = 'localhost';
$db   = 'neemshotel_db';
$user = 'root';
$pass = '';
```

## Default Admin Account

- **Email**: admin@neemshotel.com
- **Password**: admin123

**Important**: Change the default password after first login for security.

## Project Structure

```
hotel-management/
├── assets/              # Static assets (images, icons)
├── css/                 # Stylesheets
├── database/            # Database configuration and setup
├── fpdf/                # PDF generation library
├── js/                  # JavaScript files
├── php/                 # PHP backend files
├── vendor/              # Composer dependencies
├── index.php            # Main entry point
├── login.php            # Login page
├── dashboard.php        # Admin dashboard
├── setup_database.php   # Database setup script
└── README.md           # This file
```

## Features Overview

### Admin Features
- Manage multiple hotels
- Assign hotel managers
- View system-wide reports
- Manage user accounts

### Manager Features
- Manage hotel rooms and categories
- Handle bookings and check-ins
- Generate reports
- Manage guest information

### Booking System
- Room availability checking
- Online booking process
- Check-in/check-out management
- Payment tracking
- PDF receipt generation

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Make sure MySQL is running
   - Check database credentials in `database/config.php`
   - Ensure database `neemshotel_db` exists

2. **Page Not Found (404)**
   - Verify Apache is running
   - Check file permissions
   - Ensure files are in the correct web server directory

3. **Permission Denied**
   - Check file and folder permissions
   - Ensure web server has read/write access

4. **PDF Generation Issues**
   - Make sure the `fpdf` library is properly included
   - Check write permissions for PDF generation

### Getting Help

If you encounter any issues:
1. Check the error logs in your web server
2. Verify all prerequisites are installed
3. Ensure database setup completed successfully
4. Check file permissions and paths

## Security Notes

- Change default admin password immediately
- Keep your web server and PHP versions updated
- Regularly backup your database
- Use HTTPS in production environments

## License

This project is for educational and commercial use.

## Support

For support or questions, please refer to the project documentation or contact the development team.
