<?php
// Simple test to isolate the issue
$hotel_id = 1;

// Connect to database
$host = '127.0.0.1';
$db   = 'hotel';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

echo "<h1>Simple Test - Room Data</h1>";

// Get rooms (same as pricing page)
$rooms_table = "rooms_hotel_{$hotel_id}";
$stmt = $pdo->prepare("
    SELECT r.*, rc.name as category_name, rc.description as category_description 
    FROM `$rooms_table` r 
    LEFT JOIN room_categories rc ON r.category = rc.name AND rc.hotel_id = ? 
    GROUP BY r.id
    ORDER BY r.room_number, r.id
");
$stmt->execute([$hotel_id]);
$rooms = $stmt->fetchAll();

echo "<h2>Step 1: Raw Room Data</h2>";
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Room Number</th><th>Category</th></tr>";
foreach ($rooms as $room) {
    echo "<tr>";
    echo "<td>{$room['id']}</td>";
    echo "<td>{$room['room_number']}</td>";
    echo "<td>{$room['category']}</td>";
    echo "</tr>";
}
echo "</table>";

// Get booking status
$bookings_table = "bookings_hotel_{$hotel_id}";
$stmt = $pdo->prepare("
    SELECT room_id, COUNT(*) as booking_count 
    FROM `$bookings_table` 
    WHERE status = 'active' 
    GROUP BY room_id
");
$stmt->execute();
$room_bookings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

echo "<h2>Step 2: Room Bookings</h2>";
echo "<table border='1'>";
echo "<tr><th>Room ID</th><th>Booking Count</th></tr>";
foreach ($room_bookings as $room_id => $booking_count) {
    echo "<tr>";
    echo "<td>{$room_id}</td>";
    echo "<td>{$booking_count}</td>";
    echo "</tr>";
}
echo "</table>";

// Process rooms
echo "<h2>Step 3: Processed Rooms</h2>";
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Room Number</th><th>Has Bookings</th><th>Is Booked</th></tr>";

$unavailable_count = 0;
$available_count = 0;

foreach ($rooms as $room) {
    $has_bookings = isset($room_bookings[$room['id']]) && $room_bookings[$room['id']] > 0;
    $is_booked = $has_bookings;
    
    if ($is_booked) {
        $unavailable_count++;
        $status = "Unavailable";
        $color = "red";
    } else {
        $available_count++;
        $status = "Available";
        $color = "green";
    }
    
    echo "<tr>";
    echo "<td>{$room['id']}</td>";
    echo "<td>{$room['room_number']}</td>";
    echo "<td>" . ($has_bookings ? 'Yes' : 'No') . "</td>";
    echo "<td style='color: {$color}; font-weight: bold;'>{$status}</td>";
    echo "</tr>";
}
echo "</table>";

echo "<h2>Summary:</h2>";
echo "<p><strong>Total Rooms:</strong> " . count($rooms) . "</p>";
echo "<p><strong>Unavailable:</strong> {$unavailable_count}</p>";
echo "<p><strong>Available:</strong> {$available_count}</p>";

if ($unavailable_count == 4) {
    echo "<p style='color: green; font-weight: bold;'>✓ Correct! Should show 4 unavailable rooms</p>";
} else {
    echo "<p style='color: red; font-weight: bold;'>✗ Issue found! Expected 4, got {$unavailable_count}</p>";
}
?> 