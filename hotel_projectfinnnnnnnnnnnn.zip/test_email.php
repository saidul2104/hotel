<?php
// Test Email Script for Hosting Environment
// Use this to test if email is working on your hosting

require_once 'database/config.php';
require_once 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require_once 'vendor/phpmailer/phpmailer/src/SMTP.php';
require_once 'vendor/phpmailer/phpmailer/src/Exception.php';
require_once 'php/email_config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Test email configuration
$test_email = 'your-test-email@gmail.com'; // Change this to your email

echo "<h2>Email Test Results</h2>";

// Test Method 1: Built-in mail function
echo "<h3>Testing Method 1: Built-in mail() function</h3>";
try {
    $mail = new PHPMailer(true);
    $email_config = configure_phpmailer($mail, 'hosting');
    
    $mail->setFrom($email_config['from_email'], $email_config['from_name']);
    $mail->addAddress($test_email, 'Test User');
    $mail->Subject = 'Test Email from Hotel System - Method 1';
    $mail->Body = "This is a test email from your hotel management system.\n\nIf you receive this, Method 1 (built-in mail) is working!";
    
    $mail->send();
    echo "<p style='color: green;'>✅ Method 1 SUCCESS: Email sent using built-in mail() function</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Method 1 FAILED: " . $e->getMessage() . "</p>";
}

// Test Method 2: Hosting SMTP
echo "<h3>Testing Method 2: Hosting SMTP</h3>";
try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'localhost';
    $mail->SMTPAuth = false;
    $mail->Port = 25;
    
    $mail->setFrom('hotelgrowthsolutions@gmail.com', 'Hotel System');
    $mail->addAddress($test_email, 'Test User');
    $mail->Subject = 'Test Email from Hotel System - Method 2';
    $mail->Body = "This is a test email from your hotel management system.\n\nIf you receive this, Method 2 (hosting SMTP) is working!";
    
    $mail->send();
    echo "<p style='color: green;'>✅ Method 2 SUCCESS: Email sent using hosting SMTP</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Method 2 FAILED: " . $e->getMessage() . "</p>";
}

// Test Method 3: Gmail SMTP (if you have credentials)
echo "<h3>Testing Method 3: Gmail SMTP</h3>";
echo "<p style='color: orange;'>⚠️ To test Gmail SMTP, update the credentials in email_config.php first</p>";

echo "<h3>Database Connection Test</h3>";
try {
    $pdo = get_pdo_connection();
    echo "<p style='color: green;'>✅ Database connection successful</p>";
    echo "<p>Connected to: " . $db . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database connection failed: " . $e->getMessage() . "</p>";
}

echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>Update the test email address above to your email</li>";
echo "<li>Run this test to see which method works</li>";
echo "<li>If Method 1 or 2 works, your email should work</li>";
echo "<li>If all methods fail, contact your hosting provider about email settings</li>";
echo "</ol>";
?> 